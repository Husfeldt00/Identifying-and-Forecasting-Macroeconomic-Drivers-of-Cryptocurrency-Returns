# =========================================================================
# SCRIPT: PLOT AF RENSET GULD-DATA (LOG-AFKAST ELLER REKONSTRUERET PRIS)
# =========================================================================
library(dplyr)
library(ggplot2)

# 1. Definer stien til din renserfil
# (Du kan rette mappenavnet herunder, hvis du skifter mellem 'Updated' og 'LiteCoin')
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_GOLD.csv"

print("Indlæser renset guld-data (log-afkast)...")
gold_data <- read.csv(fil_sti)

# Formater datoer og filtrer fra 2010
gold_data <- gold_data %>%
  mutate(Date = as.Date(Date)) %>%
  filter(Date >= "2020-01-01") %>%
  arrange(Date) %>%
  na.omit()

# =========================================================================
# PLOT 1: DE RENE LOG-AFKAST (Volatilitet / Stationær tidsrække)
# =========================================================================
print("Genererer plot for log-afkast...")

plot_afkast <- ggplot(gold_data, aes(x = Date, y = Cleaned_GOLD)) +
  geom_line(color = "#1f78b4", size = 0.4) + # Flot blå økonometrisk farve
  theme_minimal(base_size = 14) +
  labs(
    title = "Guld: Logaritmiske afkast (2010 - Frem)",
    subtitle = "Første log-difference jf. Panagiotidis (2018)",
    x = "",
    y = "Log-afkast (r_t)"
  ) +
  theme(plot.title = element_text(face = "bold"))

# Gemmer automatisk som PDF i din mappe
gem_sti_afkast <- paste0(dirname(fil_sti), "/Guld_Log_Afkast.pdf")
ggsave(gem_sti_afkast, plot = plot_afkast, width = 10, height = 5, device = "pdf")


# =========================================================================
# PLOT 2: REKONSTRUERET PRISUDVIKLING (Kumulativ prissti)
# =========================================================================
print("Rekonstruerer prisstien ud fra log-afkast...")

# Siden r_t = log(P_t / P_t-1), vil exp(cumsum(r_t)) give os P_t / P_0
gold_data <- gold_data %>%
  mutate(Indexed_Price = exp(cumsum(Cleaned_GOLD)))

print("Genererer plot for rekonstrueret prisudvikling...")

plot_pris <- ggplot(gold_data, aes(x = Date, y = Indexed_Price)) +
  geom_line(color = "#D4AF37", size = 0.8) + # Klassisk guld-farve
  theme_minimal(base_size = 14) +
  labs(
    title = "Guld: Rekonstrueret Prisudvikling (2010 - Frem)",
    subtitle = "Akkumuleret prissti rekonstrueret fra log-afkast (Indekseret: Start = 1)",
    x = "",
    y = "Indekseret prisniveau (P_t / P_0)"
  ) +
  theme(plot.title = element_text(face = "bold"))

# Gemmer automatisk som PDF i din mappe
gem_sti_pris <- paste0(dirname(fil_sti), "/Guld_Prisudvikling_Rekonstrueret.pdf")
ggsave(gem_sti_pris, plot = plot_pris, width = 10, height = 5, device = "pdf")

# =========================================================================
# AFSLUTNING
# =========================================================================
cat("\n=======================================================\n")
cat("✅ SUCCESS: Begge plots er genereret og gemt som PDF!\n")
cat("Du kan finde dem direkte i din mappe:\n")
cat("1. Log-afkast: ", gem_sti_afkast, "\n")
cat("2. Prisudvikling:", gem_sti_pris, "\n")
cat("=======================================================\n")