# =========================================================================
# SCRIPT: MODEL FUNKTIONER (LASSO, OCMT & BMT)
# =========================================================================

library(glmnet) 

# =========================================================================
# HJÆLPEFUNKTION: SIKKER T-STATISTIK
# =========================================================================
# Beregner t-statistik for en enkelt variabel og returnerer 0, hvis 
# variablen ingen varians har (sd=0), eller hvis regressionen crasher.
safe_t_stat <- function(y_vec, x_vec) {
  if(sd(x_vec) == 0) return(0)
  fit <- tryCatch(lm(y_vec ~ x_vec), error = function(e) NULL)
  if(is.null(fit) || nrow(summary(fit)$coefficients) < 2) return(0)
  return(summary(fit)$coefficients[2, 3])
}

# =========================================================================
# OCMT FUNKTIONER (One Covariate at a time Multiple Testing)
# =========================================================================

# Standard OCMT (Delta = 1.0)
run_ocmt_safe <- function(X, y, p_val) {
  N <- ncol(X); c_p <- qnorm(1 - p_val / (2 * N))
  active_set <- c(); remaining <- colnames(X)
  t_stats <- sapply(remaining, function(v) safe_t_stat(y, X[, v]))
  new_selected <- names(t_stats)[abs(t_stats) > c_p]
  active_set <- c(active_set, new_selected); remaining <- setdiff(remaining, new_selected)
  while(length(new_selected) > 0 & length(remaining) > 0) {
    resids <- residuals(lm(y ~ X[, active_set, drop=FALSE]))
    t_stats <- sapply(remaining, function(v) safe_t_stat(resids, X[, v]))
    new_selected <- names(t_stats)[abs(t_stats) > c_p]
    active_set <- c(active_set, new_selected); remaining <- setdiff(remaining, new_selected)
  }
  return(active_set)
}

# OCMT med mildere straf (Delta = 0.5)
run_ocmt_safe_0.5 <- function(X, y, p_val) {
  N <- ncol(X); c_p <- qnorm(1 - p_val / (2 * N^0.5))
  active_set <- c(); remaining <- colnames(X)
  t_stats <- sapply(remaining, function(v) safe_t_stat(y, X[, v]))
  new_selected <- names(t_stats)[abs(t_stats) > c_p]
  active_set <- c(active_set, new_selected); remaining <- setdiff(remaining, new_selected)
  while(length(new_selected) > 0 & length(remaining) > 0) {
    resids <- residuals(lm(y ~ X[, active_set, drop=FALSE]))
    t_stats <- sapply(remaining, function(v) safe_t_stat(resids, X[, v]))
    new_selected <- names(t_stats)[abs(t_stats) > c_p]
    active_set <- c(active_set, new_selected); remaining <- setdiff(remaining, new_selected)
  }
  return(active_set)
}

# OCMT med hårdere straf (Delta = 2.0)
run_ocmt_safe_2.0 <- function(X, y, p_val) {
  N <- ncol(X); c_p <- qnorm(1 - p_val / (2 * N^2))
  active_set <- c(); remaining <- colnames(X)
  t_stats <- sapply(remaining, function(v) safe_t_stat(y, X[, v]))
  new_selected <- names(t_stats)[abs(t_stats) > c_p]
  active_set <- c(active_set, new_selected); remaining <- setdiff(remaining, new_selected)
  while(length(new_selected) > 0 & length(remaining) > 0) {
    resids <- residuals(lm(y ~ X[, active_set, drop=FALSE]))
    t_stats <- sapply(remaining, function(v) safe_t_stat(resids, X[, v]))
    new_selected <- names(t_stats)[abs(t_stats) > c_p]
    active_set <- c(active_set, new_selected); remaining <- setdiff(remaining, new_selected)
  }
  return(active_set)
}

# =========================================================================
# BMT FUNKTIONER (Boosted Multiple Testing)
# =========================================================================

# Standard BMT (Delta = 1.0)
run_bmt_safe <- function(X, y, p_val) {
  N <- ncol(X); c_p <- qnorm(1 - p_val / (2 * N))
  active_set <- c(); remaining <- colnames(X); target <- y
  while(length(remaining) > 0) {
    t_stats <- sapply(remaining, function(v) safe_t_stat(target, X[, v]))
    max_var <- names(which.max(abs(t_stats)))
    if(abs(t_stats[max_var]) > c_p) {
      active_set <- c(active_set, max_var); remaining <- setdiff(remaining, max_var)
      target <- residuals(lm(y ~ X[, active_set, drop=FALSE]))
    } else break
  }
  return(active_set)
}

# BMT med mildere straf (Delta = 0.5)
run_bmt_safe_0.5 <- function(X, y, p_val) {
  N <- ncol(X); c_p <- qnorm(1 - p_val / (2 * N^0.5))
  active_set <- c(); remaining <- colnames(X); target <- y
  while(length(remaining) > 0) {
    t_stats <- sapply(remaining, function(v) safe_t_stat(target, X[, v]))
    max_var <- names(which.max(abs(t_stats)))
    if(abs(t_stats[max_var]) > c_p) {
      active_set <- c(active_set, max_var); remaining <- setdiff(remaining, max_var)
      target <- residuals(lm(y ~ X[, active_set, drop=FALSE]))
    } else break
  }
  return(active_set)
}

# BMT med hårdere straf (Delta = 2.0)
run_bmt_safe_2.0 <- function(X, y, p_val) {
  N <- ncol(X); c_p <- qnorm(1 - p_val / (2 * N^2))
  active_set <- c(); remaining <- colnames(X); target <- y
  while(length(remaining) > 0) {
    t_stats <- sapply(remaining, function(v) safe_t_stat(target, X[, v]))
    max_var <- names(which.max(abs(t_stats)))
    if(abs(t_stats[max_var]) > c_p) {
      active_set <- c(active_set, max_var); remaining <- setdiff(remaining, max_var)
      target <- residuals(lm(y ~ X[, active_set, drop=FALSE]))
    } else break
  }
  return(active_set)
}

# =========================================================================
# LASSO FUNKTION
# =========================================================================

# LASSO Machine Learning Selektion
get_lasso_vars <- function(X, y) {
  cv_f <- tryCatch(cv.glmnet(as.matrix(X), y, alpha=1, standardize=FALSE), error=function(e) NULL)
  if(!is.null(cv_f)){
    c <- as.matrix(coef(cv_f, s="lambda.min"))
    return(rownames(c)[c[,1] != 0 & rownames(c) != "(Intercept)"])
  } else return(character(0))
}
