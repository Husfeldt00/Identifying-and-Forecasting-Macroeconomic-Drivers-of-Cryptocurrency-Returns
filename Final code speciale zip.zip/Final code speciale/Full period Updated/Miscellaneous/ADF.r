# =========================================================================
# TEST FOR STATIONARITET (Augmented Dickey-Fuller Test)
# =========================================================================
# install.packages("tseries") # Fjern # forrest, hvis du ikke har den
library(tseries)
library(dplyr)



# Funktion der tjekker stationaritet
check_stationarity <- function(df) {
  
  # Vi kigger kun på de numeriske kolonner
  num_data <- df %>% select(where(is.numeric))
  
  # Vi bygger en tom tabel til at gemme resultaterne i
  results <- data.frame(
    Variabel = character(),
    ADF_Statistic = numeric(),
    P_Value = numeric(),
    Konklusion = character(),
    stringsAsFactors = FALSE
  )
  
  # Loop gennem hver eneste variabel i datasættet
  for (col_name in colnames(num_data)) {
    vec <- na.omit(num_data[[col_name]]) # Fjern evt. manglende værdier
    
    # Kør kun testen, hvis der rent faktisk er data og varians i kolonnen
    if(length(vec) > 10 && var(vec) > 0) {
      
      # suppressWarnings fjerner små R-advarsler om p-værdier der er "mindre end 0.01"
      test <- suppressWarnings(adf.test(vec, alternative = "stationary"))
      
      # Hvis p-værdien er under 0.05, er dataen stationær!
      conclusion <- ifelse(test$p.value <= 0.05, "Stationær", "IKKE-stationær (Advarsel)")
      
      # Tilføj resultatet som en ny række i tabellen
      results <- rbind(results, data.frame(
        Variabel = col_name,
        ADF_Statistic = round(test$statistic, 4),
        P_Value = round(test$p.value, 4),
        Konklusion = conclusion
      ))
    }
  }
  
  # Sorterer så evt. ikke-stationære variabler ligger i toppen
  results <- results %>% arrange(desc(Konklusion), Variabel)
  
  return(results)
}

# KØR TESTEN PÅ DIT DATA
# Vi bruger 'df_full' (din masterfil), men fjerner dato-kolonnen, da man ikke kan teste en dato.
adf_resultater <- check_stationarity(df_full %>% select(-Date))

# Print det flotte resultat
cat("\n=======================================================\nRESULTATER AF ADF-TEST (Signifikansniveau: 5%)\n=======================================================\n")
print(adf_resultater)
