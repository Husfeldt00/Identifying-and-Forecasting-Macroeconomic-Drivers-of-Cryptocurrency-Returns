library(dplyr)

# Antager at din datafil hedder 'df_full' (som i de tidligere scripts)
# Vi fjerner Date og ALLE crypto-relaterede kolonner
makro_data <- df_full %>% 
  select(-Date) %>%
  select(-any_of(c(
    "Cleaned_BTC", "Lag1_BTC", "Bitcoin_Volume", 
    "Cleaned_ETH", "Lag1_ETH", "ETH_Volume",
    "Cleaned_LTC", "Lag1_LTC", "Litecoin_Volume",
    "Cleaned_XRP", "Lag1_XRP", "XRP_Volume"
  )))

# Hent navnene på de resterende variabler
makro_variabler <- colnames(makro_data)

# Lav det til en pæn dataframe, så det er nemt at læse
makro_oversigt <- data.frame(
  Nummer = 1:length(makro_variabler),
  Makrovariabel = sort(makro_variabler) # Sorteret alfabetisk
)

cat("\n=======================================================\n")
cat("OVERSIGT OVER TILGÆNGELIGE MAKROVARIABLER I MODELLEN\n")
cat("Totalt antal makrovariabler:", length(makro_variabler), "\n")
cat("=======================================================\n")
print(makro_oversigt, row.names = FALSE)
