# =========================================================================
# OUT-OF-SAMPLE FORECASTING (80/20 SPLIT)
# PRE-COVID SCENARIO (CONDITIONAL / MED LAG-VARIABEL & FWL)
# =========================================================================
library(dplyr)
library(tidyr)
library(glmnet)
library(lubridate)

print("Starter 80/20 Out-of-Sample Forecasting (Pre-COVID - Conditional)...")

# 1. Definer sti og indlæs data

source("00_paths.R")
basis_sti <- cleaned_sti

fuld_fil_sti <- paste0(basis_sti, "MASTER_Full_Period.csv")

df_full <- read.csv(fuld_fil_sti)
df_full$Date <- as.Date(df_full$Date)

# 2. DEFINER PRE-COVID PERIODE
corona_start <- as.Date("2020-03-11")
cutoff_date <- corona_start - days(100)

cat("Afskærer al data efter:", as.character(cutoff_date), "\n\n")

# Filtrer data, lav lag og fjern NAs
df_full <- df_full %>%
  filter(Date <= cutoff_date) %>%
  arrange(Date) %>%
  mutate(Lag1_BTC = lag(Cleaned_BTC)) %>%
  na.omit()

# 3. SKAB 80/20 SPLIT
N_total <- nrow(df_full)
N_train <- floor(0.80 * N_total)

df_train <- df_full[1:N_train, ]
df_test  <- df_full[(N_train + 1):N_total, ]

cat(sprintf("Datasæt delt (80/20): Træner på %d dage. Tester (forudsiger) på %d dage.\n", N_train, nrow(df_test)))

# 4. FORBERED TRÆNINGSDATA (FWL Ortogonalisering - LAG INKLUDERET)
y_train <- df_train$Cleaned_BTC
y_lag_train <- df_train$Lag1_BTC
X_macro_train <- df_train %>% select(-Date, -Cleaned_BTC, -Lag1_BTC)

# Sikkerhed: Rens for 0-varians i træningssættet
X_macro_train <- X_macro_train %>% select(where(~ sd(.) > 0))

# FWL Projektion: Rens makro og y for y_lag (Momentum)
y_tilde_train <- residuals(lm(y_train ~ y_lag_train))
X_tilde_train <- matrix(NA, nrow=nrow(X_macro_train), ncol=ncol(X_macro_train))
colnames(X_tilde_train) <- colnames(X_macro_train)
for(j in 1:ncol(X_macro_train)) {
  X_tilde_train[,j] <- residuals(lm(X_macro_train[[j]] ~ y_lag_train))
}

# 5. TRÆNING: UDVÆLG VARIABLER PÅ 80% DATA
get_lasso_vars_controlled <- function(X_mac, y_target, y_lagged) {
  X_full <- as.matrix(cbind(y_lagged, X_mac))
  penalties <- c(0, rep(1, ncol(X_mac))) 
  cv_f <- tryCatch(cv.glmnet(X_full, y_target, alpha=1, penalty.factor=penalties, standardize=FALSE), error=function(e) NULL)
  if(!is.null(cv_f)){
    c <- as.matrix(coef(cv_f, s="lambda.min"))
    return(rownames(c)[c[,1] != 0 & rownames(c) != "(Intercept)" & rownames(c) != "y_lagged"])
  } else return(character(0))
}

vars_ar1   <- character(0)
vars_lasso <- get_lasso_vars_controlled(X_macro_train, y_train, y_lag_train)
vars_ocmt  <- run_ocmt_safe(as.matrix(X_tilde_train), y_tilde_train, 0.05) 
vars_bmt   <- run_bmt_safe(as.matrix(X_tilde_train), y_tilde_train, 0.05)

# 6. FORECASTING FUNKTION (Out-of-Sample)
forecast_oos <- function(navn, valgte_makro) {
  # Inkluderer altid Lag1_BTC i selve OLS-estimeringen
  if(length(valgte_makro) > 0) {
    valgte_gyldige <- intersect(valgte_makro, colnames(X_macro_train))
    df_reg_train <- data.frame(y = y_train, Lag1_BTC = y_lag_train, X_macro_train[, valgte_gyldige, drop=FALSE])
  } else {
    df_reg_train <- data.frame(y = y_train, Lag1_BTC = y_lag_train)
  }
  
  fit_train <- lm(y ~ ., data = df_reg_train)
  
  if(length(valgte_makro) > 0) {
    df_reg_test <- data.frame(Lag1_BTC = df_test$Lag1_BTC, df_test[, valgte_gyldige, drop=FALSE])
  } else {
    df_reg_test <- data.frame(Lag1_BTC = df_test$Lag1_BTC)
  }
  
  y_hat_test <- predict(fit_train, newdata = df_reg_test)
  
  e_test <- df_test$Cleaned_BTC - y_hat_test
  msfe <- mean(e_test^2)
  
  return(list(
    Navn = navn,
    Antal_Valgte = length(valgte_makro),
    MSFE = msfe,
    RMSFE = sqrt(msfe)
  ))
}

# 7. BEREGN FORECASTS
res_ar1   <- forecast_oos("1. AR(1) Baseline", vars_ar1)
res_lasso <- forecast_oos("2. LASSO", vars_lasso)
res_ocmt  <- forecast_oos("3. OCMT", vars_ocmt)
res_bmt   <- forecast_oos("4. BMT", vars_bmt)

# 8. BEREGN R2_OOS OG SAML TABEL
msfe_benchmark <- res_ar1$MSFE

byg_række <- function(res) {
  r2_oos <- 1 - (res$MSFE / msfe_benchmark)
  data.frame(
    Model = res$Navn,
    Makro_Variabler_Valgt_i_Train = res$Antal_Valgte,
    RMSFE = res$RMSFE,
    R2_OOS_pct = r2_oos * 100
  )
}

tabel_oos <- bind_rows(
  byg_række(res_ar1),
  byg_række(res_lasso),
  byg_række(res_ocmt),
  byg_række(res_bmt)
)

cat("\n=======================================================\n")
cat(" OUT-OF-SAMPLE FORECASTING (80/20 SPLIT - PRE-COVID) \n")
cat(" CONDITIONAL: Modellerne HAR adgang til lag (FWL) \n")
cat("=======================================================\n")
print(tabel_oos %>% 
        mutate(
          RMSFE = sprintf("%.5f", RMSFE),
          R2_OOS_pct = sprintf("%.3f %%", R2_OOS_pct)
        ))
cat("=======================================================\n")

cat("Variabler valgt af BMT: ", paste(vars_bmt, collapse = ", "), "\n")
cat("Variabler valgt af OCMT: ", paste(vars_ocmt, collapse = ", "), "\n")
cat("Variabler valgt af LASSO: ", paste(vars_lasso, collapse = ", "), "\n")

cat("\n--- DATO FOR OUT-OF-SAMPLE TEST ---\n")
cat("Første testdag er:", as.character(min(df_test$Date)), "\n")
cat("Sidste testdag er:", as.character(max(df_test$Date)), "\n")
cat("Første træningsdag er:", as.character(min(df_train$Date)), "\n")
cat("=======================================================\n")
