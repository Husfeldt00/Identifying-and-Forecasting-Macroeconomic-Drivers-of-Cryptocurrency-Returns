# =========================================================================
# KOEFFICIENT SCRIPT: LASSO, OCMT, BMT (INKL. DELTA) OG HEATMAP-KLARGØRING
# =========================================================================
# install.packages("tidyr")
# install.packages("glmnet")
library(dplyr)
library(tidyr)
library(glmnet)
library(ggplot2)




source("00_paths.R")
basis_sti <- cleaned_sti

filer <- c("MASTER_Full_Period.csv", "MASTER_P1.csv", "MASTER_P2.csv", "MASTER_P3.csv", "MASTER_P4.csv")
navne <- c("Full_Period", "P1", "P2", "P3", "P4")

# =========================================================================
# 2. FUNKTIONER TIL UDVÆLGELSE 
# =========================================================================


get_lasso_vars <- function(X, y) {
  cv_f <- tryCatch(cv.glmnet(X, y, alpha=1, standardize=FALSE), error=function(e) NULL)
  if(!is.null(cv_f)){
    c <- as.matrix(coef(cv_f, s="lambda.min"))
    return(rownames(c)[c[,1] != 0 & rownames(c) != "(Intercept)"])
  } else return(character(0))
}

get_results_clean <- function(file_path, period_name, method_name) {
  df <- read.csv(file_path)
  
  # Y er Bitcoin-data, X er alt andet
  y <- df$Cleaned_BTC
  X_df <- df %>% select(-Date, -Cleaned_BTC)
  
  # Fjerner NA-kolonner og nul-varians kolonner
  X_df <- X_df %>% 
    select(where(~ !any(is.na(.)))) %>% 
    select(where(~ sd(.) > 0))
  
  X_matrix <- as.matrix(X_df)
  selected_vars <- character(0)
  
  # Matcher method_name og kører den korrekte funktion.
  # Bemærk: LASSO bruger ikke p_val, mens OCMT/BMT gør.
  if(method_name == "LASSO") {
    selected_vars <- get_lasso_vars(X_matrix, y)
  } else if(method_name == "OCMT_1.0") { 
    selected_vars <- run_ocmt_safe(X_matrix, y, p_val = 0.05)
  } else if(method_name == "OCMT_0.5") {
    selected_vars <- run_ocmt_safe_0.5(X_matrix, y, p_val = 0.05)
  } else if(method_name == "OCMT_2.0") {
    selected_vars <- run_ocmt_safe_2.0(X_matrix, y, p_val = 0.05)
  } else if(method_name == "BMT_1.0") { 
    selected_vars <- run_bmt_safe(X_matrix, y, p_val = 0.05)
  } else if(method_name == "BMT_0.5") {
    selected_vars <- run_bmt_safe_0.5(X_matrix, y, p_val = 0.05)
  } else if(method_name == "BMT_2.0") {
    selected_vars <- run_bmt_safe_2.0(X_matrix, y, p_val = 0.05)
  }
  
  # Kør Post-Selection OLS
  if(length(selected_vars) > 0) {
    selected_vars <- intersect(selected_vars, colnames(X_df)) 
    df_reg <- data.frame(y = y, X_df[, selected_vars, drop=FALSE])
    fit <- lm(y ~ ., data = df_reg)
    coefs <- summary(fit)$coefficients[-1, 1, drop=FALSE]
    return(data.frame(Variable = rownames(coefs), Coef = coefs[,1], Period = period_name, stringsAsFactors = FALSE))
  } else {
    return(data.frame(Variable = character(0), Coef = numeric(0), Period = character(0), stringsAsFactors = FALSE))
  }
}

# =========================================================================
# 3. KØR FOR ALLE PERIODER OG MODELLER
# =========================================================================
# Opretter lister til at holde resultaterne for alle varianter
all_lasso    <- list()
all_ocmt_1.0 <- list(); all_ocmt_0.5 <- list(); all_ocmt_2.0 <- list()
all_bmt_1.0  <- list(); all_bmt_0.5  <- list(); all_bmt_2.0  <- list()

for (i in seq_along(navne)) {
  cat("Beregner koefficienter for:", navne[i], "...\n")
  fuld_fil_sti <- paste0(basis_sti, filer[i])
  
  all_lasso[[i]]    <- get_results_clean(fuld_fil_sti, navne[i], "LASSO")
  
  all_ocmt_1.0[[i]] <- get_results_clean(fuld_fil_sti, navne[i], "OCMT_1.0")
  all_ocmt_0.5[[i]] <- get_results_clean(fuld_fil_sti, navne[i], "OCMT_0.5")
  all_ocmt_2.0[[i]] <- get_results_clean(fuld_fil_sti, navne[i], "OCMT_2.0")
  
  all_bmt_1.0[[i]]  <- get_results_clean(fuld_fil_sti, navne[i], "BMT_1.0")
  all_bmt_0.5[[i]]  <- get_results_clean(fuld_fil_sti, navne[i], "BMT_0.5")
  all_bmt_2.0[[i]]  <- get_results_clean(fuld_fil_sti, navne[i], "BMT_2.0")
}

# =========================================================================
# 4. MATRIX-OPBYGNING 
# =========================================================================
build_matrices <- function(res_list) {
  res <- bind_rows(res_list)
  
  if(nrow(res) == 0) {
    return(list(
      print_df = data.frame(Message = "Ingen variabler valgt"),
      plot_df = data.frame()
    ))
  }
  
  res_clean <- res %>%
    mutate(Variable = gsub("Cleaned_", "", Variable),
           Variable = gsub("_", " ", Variable)) %>%
    pivot_wider(names_from = Period, values_from = Coef)
  
  manglende_perioder <- setdiff(navne, colnames(res_clean))
  if(length(manglende_perioder) > 0) {
    for(m in manglende_perioder) res_clean[[m]] <- NA
  }
  
  plot_df <- res_clean %>%
    select(Variable, all_of(navne)) %>%
    mutate(across(-Variable, ~ replace_na(as.numeric(.x), 0))) %>%
    arrange(Variable)
  
  print_df <- res_clean %>%
    select(Variable, all_of(navne)) %>%
    mutate(across(-Variable, ~ sprintf("%.3f", as.numeric(.x)))) %>%
    mutate(across(-Variable, ~ ifelse(. == "NA", "0.000", .))) %>%
    arrange(Variable)
  
  return(list(print_df = print_df, plot_df = plot_df))
}

# Byg matricer for LASSO og baseline (1.0) OCMT/BMT
matrix_lasso    <- build_matrices(all_lasso)
matrix_ocmt_1.0 <- build_matrices(all_ocmt_1.0)
matrix_bmt_1.0  <- build_matrices(all_bmt_1.0)

# Byg matricer for delta-varianterne (0.5 og 2.0)
matrix_ocmt_0.5 <- build_matrices(all_ocmt_0.5)
matrix_ocmt_2.0 <- build_matrices(all_ocmt_2.0)
matrix_bmt_0.5  <- build_matrices(all_bmt_0.5)
matrix_bmt_2.0  <- build_matrices(all_bmt_2.0)


# =========================================================================
# 5. UDSKRIV RESULTATER I KONSOLLEN
# =========================================================================
cat("\n===========================================================\n")
cat("--- POST-LASSO OLS: ALLE PERIODER ---\n")
print(as.data.frame(matrix_lasso$print_df), row.names = FALSE)

cat("\n===========================================================\n")

cat("--- OCMT (Delta = 1.0): ALLE PERIODER ---\n")
print(as.data.frame(matrix_ocmt_1.0$print_df), row.names = FALSE)

cat("\n--- OCMT (Delta = 0.5): ALLE PERIODER ---\n")
print(as.data.frame(matrix_ocmt_0.5$print_df), row.names = FALSE)

cat("\n--- OCMT (Delta = 2.0): ALLE PERIODER ---\n")
print(as.data.frame(matrix_ocmt_2.0$print_df), row.names = FALSE)

cat("\n===========================================================\n")
cat("--- BMT (Delta = 1.0): ALLE PERIODER ---\n")
print(as.data.frame(matrix_bmt_1.0$print_df), row.names = FALSE)

cat("\n--- BMT (Delta = 0.5): ALLE PERIODER ---\n")
print(as.data.frame(matrix_bmt_0.5$print_df), row.names = FALSE)

cat("\n--- BMT (Delta = 2.0): ALLE PERIODER ---\n")
print(as.data.frame(matrix_bmt_2.0$print_df), row.names = FALSE)
cat("\n===========================================================\n")

# =========================================================================
# 5. UDSKRIV RESULTATER I KONSOLLEN
# =========================================================================

cat("\n\n--- POST-LASSO OLS: ALLE PERIODER ---\n")
print(as.data.frame(matrix_lasso$print_df), row.names = FALSE)

cat("\n\n--- OCMT (Delta = 1.0): ALLE PERIODER ---\n")
print(as.data.frame(matrix_ocmt_1.0$print_df), row.names = FALSE)

cat("\n\n--- OCMT (Delta = 0.5): ALLE PERIODER ---\n")
print(as.data.frame(matrix_ocmt_0.5$print_df), row.names = FALSE)

cat("\n\n--- OCMT (Delta = 2.0): ALLE PERIODER ---\n")
print(as.data.frame(matrix_ocmt_2.0$print_df), row.names = FALSE)

cat("\n\n--- BMT (Delta = 1.0): ALLE PERIODER ---\n")
print(as.data.frame(matrix_bmt_1.0$print_df), row.names = FALSE)

cat("\n\n--- BMT (Delta = 0.5): ALLE PERIODER ---\n")
print(as.data.frame(matrix_bmt_0.5$print_df), row.names = FALSE)

cat("\n\n--- BMT (Delta = 2.0): ALLE PERIODER ---\n")
print(as.data.frame(matrix_bmt_2.0$print_df), row.names = FALSE)
