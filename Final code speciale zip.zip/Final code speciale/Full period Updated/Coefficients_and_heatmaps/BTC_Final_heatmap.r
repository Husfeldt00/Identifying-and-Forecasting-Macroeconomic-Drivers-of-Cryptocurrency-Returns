# =========================================================================
# SCRIPT 2: RULLENDE VINDUER OG BINÆRE HEATMAPS (LASSO + 6x OCMT/BMT)
# =========================================================================
library(dplyr)
library(tidyr)
library(glmnet)
library(ggplot2)
library(lubridate)




source("00_paths.R")
basis_sti <- cleaned_sti


# =========================================================================
# 1. KLARGØR DATA OG VARIABLER TIL Y-AKSEN
# =========================================================================
# Indlæs Full Period for at definere det rullende datasæt
df_full <- read.csv(paste0(basis_sti, "MASTER_Full_Period.csv")) %>%
  mutate(Date = as.Date(Date)) %>%
  select(
    -contains("cpnews_index_narrow"),
    -contains("cpsent_index"),
    -contains("cpu_index_broad"),
    -contains("cpu_index_narrow")
  )

# Udtræk bruttotruppen af variabler til Y-aksen
alle_mulige_variabler <- df_full %>% 
  select(-Date, -Cleaned_BTC) %>% 
  colnames() %>% 
  gsub("Cleaned_", "", .) %>% 
  gsub("_", " ", .) %>% 
  sort()

# Erstat med de korte navne til Y-aksen
alle_mulige_variabler[alle_mulige_variabler == "cpu index gavriilidis"] <- "CPU"
alle_mulige_variabler[alle_mulige_variabler == "fed standardized"] <- "FED"
alle_mulige_variabler[alle_mulige_variabler == "gpr standardized"] <- "GPR"
alle_mulige_variabler[alle_mulige_variabler == "gpra standardized"] <- "GPRA"
alle_mulige_variabler[alle_mulige_variabler == "gprt standardized"] <- "GPRT"
alle_mulige_variabler[alle_mulige_variabler == "cpnews index broad"]    <- "CPN"
alle_mulige_variabler <- sort(alle_mulige_variabler)

# =========================================================================
# 2. DEFINER FUNKTION TIL AT TRÆKKE VARIABLER
# =========================================================================
get_vars_only <- function(df_window, method) {
  y <- df_window$Cleaned_BTC
  X_df <- df_window %>% select(-Date, -Cleaned_BTC)
  
  # Beholder den strenge NA-filtrering for in-sample (sletter kolonner med NA i vinduet)
  X_df <- X_df %>% 
    select(where(~ !any(is.na(.)))) %>% 
    select(where(~ sd(.) > 0))
  
  X_matrix <- as.matrix(X_df)
  
  if(method == "LASSO") {
    set.seed(123)
    cv_f <- tryCatch(cv.glmnet(X_matrix, y, alpha=1, standardize=FALSE), error=function(e) NULL)
    if(!is.null(cv_f)){
      c <- as.matrix(coef(cv_f, s="lambda.min"))
      vars <- rownames(c)[c[,1] != 0 & rownames(c) != "(Intercept)"]
      return(vars)
    } else return(character(0))
    
  } else if(method == "OCMT_1.0") { return(run_ocmt_safe(X_matrix, y, p_val = 0.05))
  } else if(method == "OCMT_0.5") { return(run_ocmt_safe_0.5(X_matrix, y, p_val = 0.05))
  } else if(method == "OCMT_2.0") { return(run_ocmt_safe_2.0(X_matrix, y, p_val = 0.05))
  } else if(method == "BMT_1.0")  { return(run_bmt_safe(X_matrix, y, p_val = 0.05))
  } else if(method == "BMT_0.5")  { return(run_bmt_safe_0.5(X_matrix, y, p_val = 0.05))
  } else if(method == "BMT_2.0")  { return(run_bmt_safe_2.0(X_matrix, y, p_val = 0.05))
  }
}

# =========================================================================
# 3. DEFINER DATOER FOR RULLENDE VINDUER
# =========================================================================
start_date <- min(df_full$Date, na.rm = TRUE)
end_date   <- max(df_full$Date, na.rm = TRUE)

window_ends <- seq(from = start_date + days(1095), to = end_date, by = "3 months")
window_labels <- format(window_ends, "%Y-%m")

# =========================================================================
# 4. KØR DET RULLENDE LOOP FOR ALLE 7 MODELLER
# =========================================================================
# Vi definerer alle modeller og laver en liste til at holde resultaterne for hver
modeller <- c("LASSO", "OCMT_1.0", "OCMT_0.5", "OCMT_2.0", "BMT_1.0", "BMT_0.5", "BMT_2.0")
results_all <- setNames(replicate(length(modeller), list(), simplify = FALSE), modeller)

cat("\nKører data igennem", length(window_ends), "rullende vinduer for 7 modeller...\n")

for(i in seq_along(window_ends)) {
  w_end <- window_ends[i]
  w_start <- w_end - days(1095)
  label <- window_labels[i]
  
  cat(sprintf("Beregner vindue %d/%d (Slutdato: %s)...\n", i, length(window_ends), label))
  
  df_window <- df_full %>% filter(Date > w_start & Date <= w_end)
  
  # Loop gennem de 7 modeller for det aktuelle vindue
  for(mod in modeller) {
    vars_valgt <- get_vars_only(df_window, mod)
    if(length(vars_valgt) > 0) {
      results_all[[mod]][[i]] <- data.frame(Window = label, Variable = vars_valgt, Selected = 1, stringsAsFactors = FALSE)
    }
  }
}

# =========================================================================
# 5. HEATMAP PLOT-FUNKTION 
# =========================================================================
plot_binary_heatmap <- function(results_list, model_name, all_labels, all_vars_list) {
  df_res <- bind_rows(results_list)
  
  if(nrow(df_res) == 0) {
    cat("Springer over Heatmap for", model_name, "- Ingen variabler blev valgt i nogen vinduer.\n")
    return(NULL)
  }
  
  df_res <- df_res %>% 
    mutate(Variable = gsub("Cleaned_", "", Variable),
           Variable = gsub("_", " ", Variable))
  
  grid <- expand.grid(Window = all_labels, Variable = all_vars_list, stringsAsFactors = FALSE)
  
  plot_df <- grid %>%
    left_join(df_res, by = c("Window", "Variable")) %>%
    mutate(Selected = ifelse(is.na(Selected), 0, 1)) %>%
    mutate(Selected = factor(Selected, levels = c(0, 1)))
  
  plot_df$Window <- factor(plot_df$Window, levels = all_labels)
  plot_df$Variable <- factor(plot_df$Variable, levels = rev(all_vars_list))
  
  # Dynamisk undertitel der fanger delta-værdien
  undertitel <- "Three years training period over three month intervals"
  if(grepl("0.5", model_name)) undertitel <- paste(undertitel, "(delta = 0.5)")
  if(grepl("1.0", model_name)) undertitel <- paste(undertitel, "(delta = 1.0)")
  if(grepl("2.0", model_name)) undertitel <- paste(undertitel, "(delta = 2.0)")
  
  p <- ggplot(plot_df, aes(x = Window, y = Variable, fill = Selected)) +
    geom_tile(color = "grey80", size = 0.3) +
    scale_fill_manual(values = c("0" = "white", "1" = "#1f78b4"), guide = "none") +
    theme_minimal(base_size = 12) +
    labs(
      title = paste("BTC Variable Selection:", model_name, "over the full period"),
      subtitle = undertitel,
      x = "Enddate",
      y = ""
    ) +
    theme(
      axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1, size = 9),
      panel.grid = element_blank()
    )
  
  pdf_sti <- paste0(basis_sti, "Heatmap_Rolling_BTC_", model_name, ".pdf")
  ggsave(filename = pdf_sti, plot = p, width = 11, height = 9, device = "pdf")
  cat("Gemt:", pdf_sti, "\n")
}

# =========================================================================
# 6. GENERER PLOTS FOR ALLE 7 MODELLER
# =========================================================================

for(mod in modeller) {
  plot_binary_heatmap(results_all[[mod]], mod, window_labels, alle_mulige_variabler)
}
