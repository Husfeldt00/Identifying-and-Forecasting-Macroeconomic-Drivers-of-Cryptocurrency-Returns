# =========================================================================
# SCRIPT 2: LITECOIN - RULLENDE VINDUER OG BINÆRE HEATMAPS
# =========================================================================
library(dplyr)
library(tidyr)
library(glmnet)
library(ggplot2)
library(lubridate)




source("00_paths.R")
basis_sti <- cleaned_sti


# =========================================================================
# 1. KLARGØR DATA OG VARIABLER TIL Y-AKSEN
# =========================================================================
df_full <- read.csv(paste0(basis_sti, "MASTER_LITECOIN_Full_Period.csv")) %>%
  mutate(Date = as.Date(Date)) %>%
  select(
    -contains("cpnews_index_narrow"),
    -contains("cpsent_index"),
    -contains("cpu_index_broad"),
    -contains("cpu_index_narrow"),
    -contains("Cleaned_BTC") # Ekskluder BTC
  )

alle_mulige_variabler <- df_full %>% 
  select(-Date, -Cleaned_LTC) %>% 
  colnames() %>% 
  gsub("Cleaned_", "", .) %>% 
  gsub("_", " ", .)

alle_mulige_variabler[alle_mulige_variabler == "cpu index gavriilidis"] <- "CPU"
alle_mulige_variabler[alle_mulige_variabler == "fed standardized"] <- "FED"
alle_mulige_variabler[alle_mulige_variabler == "gpr standardized"] <- "GPR"
alle_mulige_variabler[alle_mulige_variabler == "gpra standardized"] <- "GPRA"
alle_mulige_variabler[alle_mulige_variabler == "gprt standardized"] <- "GPRT"
alle_mulige_variabler[alle_mulige_variabler == "cpnews index broad"]    <- "CPN"
alle_mulige_variabler <- sort(alle_mulige_variabler)

# =========================================================================
# 2. DEFINER FUNKTION TIL AT TRÆKKE VARIABLER
# =========================================================================
get_vars_only <- function(df_window, method) {
  y <- df_window$Cleaned_LTC
  X_df <- df_window %>% select(-Date, -Cleaned_LTC)
  
  X_df <- X_df %>% 
    select(where(~ !any(is.na(.)))) %>% 
    select(where(~ sd(.) > 0))
  
  X_matrix <- as.matrix(X_df)
  
  if(method == "LASSO") {
    set.seed(123)
    cv_f <- tryCatch(cv.glmnet(X_matrix, y, alpha=1, standardize=FALSE), error=function(e) NULL)
    if(!is.null(cv_f)){
      c <- as.matrix(coef(cv_f, s="lambda.min"))
      return(rownames(c)[c[,1] != 0 & rownames(c) != "(Intercept)"])
    } else return(character(0))
  } else if(method == "OCMT") {
    return(run_ocmt_safe(X_matrix, y, p_val = 0.05))
  } else if(method == "BMT") {
    return(run_bmt_safe(X_matrix, y, p_val = 0.05))
  }
}

# =========================================================================
# 3. DATOER OG RULLENDE LOOP
# =========================================================================
start_date <- min(df_full$Date, na.rm = TRUE)
end_date   <- max(df_full$Date, na.rm = TRUE)

window_ends <- seq(from = start_date + days(1095), to = end_date, by = "3 months")
window_labels <- format(window_ends, "%Y-%m")

results_lasso <- list(); results_ocmt <- list(); results_bmt <- list()

cat("\nKører Litecoin data igennem", length(window_ends), "rullende vinduer...\n")

for(i in seq_along(window_ends)) {
  w_end <- window_ends[i]
  w_start <- w_end - days(1095)
  label <- window_labels[i]
  
  cat(sprintf("Beregner vindue %d/%d (Slutdato: %s)...\n", i, length(window_ends), label))
  
  df_window <- df_full %>% filter(Date > w_start & Date <= w_end)
  
  vars_lasso <- get_vars_only(df_window, "LASSO")
  vars_ocmt  <- get_vars_only(df_window, "OCMT")
  vars_bmt   <- get_vars_only(df_window, "BMT")
  
  if(length(vars_lasso) > 0) results_lasso[[i]] <- data.frame(Window = label, Variable = vars_lasso, Selected = 1, stringsAsFactors = FALSE)
  if(length(vars_ocmt) > 0)  results_ocmt[[i]]  <- data.frame(Window = label, Variable = vars_ocmt, Selected = 1, stringsAsFactors = FALSE)
  if(length(vars_bmt) > 0)   results_bmt[[i]]   <- data.frame(Window = label, Variable = vars_bmt, Selected = 1, stringsAsFactors = FALSE)
}

# =========================================================================
# 4. HEATMAP PLOT-FUNKTION 
# =========================================================================
plot_binary_heatmap <- function(results_list, model_name, all_labels, all_vars_list) {
  df_res <- bind_rows(results_list)
  
  if(nrow(df_res) == 0) {
    cat("Springer over Heatmap for", model_name, "- Ingen variabler valgt overhovedet.\n")
    return(NULL)
  }
  
  df_res <- df_res %>% 
    mutate(Variable = gsub("Cleaned_", "", Variable), Variable = gsub("_", " ", Variable)) %>%
    mutate(Variable = case_when(Variable == "cpu index gavriilidis" ~ "CPU", Variable == "cpnews index broad" ~ "CPN", TRUE ~ Variable))
  
  grid <- expand.grid(Window = all_labels, Variable = all_vars_list, stringsAsFactors = FALSE)
  
  plot_df <- grid %>%
    left_join(df_res, by = c("Window", "Variable")) %>%
    mutate(Selected = ifelse(is.na(Selected), 0, 1), Selected = factor(Selected, levels = c(0, 1)))
  
  plot_df$Window <- factor(plot_df$Window, levels = all_labels)
  plot_df$Variable <- factor(plot_df$Variable, levels = rev(all_vars_list))
  
  p <- ggplot(plot_df, aes(x = Window, y = Variable, fill = Selected)) +
    geom_tile(color = "grey80", size = 0.3) +
    scale_fill_manual(values = c("0" = "white", "1" = "#1f78b4"), guide = "none") +
    theme_minimal(base_size = 12) +
    labs(
      title = paste("LITECOIN:", model_name, "- Rolling window variable selection over the full period"),
      subtitle = "Three years training period over three month intervals",
      x = "Enddate", y = ""
    ) +
    theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1, size = 9), panel.grid = element_blank())
  
  pdf_sti <- paste0(basis_sti, "Heatmap_Rolling_LITECOIN_", model_name, ".pdf")
  ggsave(filename = pdf_sti, plot = p, width = 11, height = 9, device = "pdf")
  cat("✅ Gemt:", pdf_sti, "\n")
}

# =========================================================================
# 5. GENERER PLOTS
# =========================================================================
cat("\nGenererer PDF-Heatmaps for Litecoin...\n")
plot_binary_heatmap(results_lasso, "LASSO", window_labels, alle_mulige_variabler)
plot_binary_heatmap(results_ocmt, "OCMT", window_labels, alle_mulige_variabler)
plot_binary_heatmap(results_bmt, "BMT", window_labels, alle_mulige_variabler)
