# =========================================================================
# SCRIPT 3: ETHEREUM & RIPPLE - FULL PERIOD (LASSO, OCMT & BMT incl. Deltas)
# =========================================================================
library(dplyr)
library(tidyr)
library(glmnet)



# 1. Definer stier (Kun Full Period)

source("00_paths.R")
basis_sti <- cleaned_sti


# =========================================================================
# 2. FUNKTIONER TIL UDVÆLGELSE
# =========================================================================
get_lasso_vars <- function(X, y) {
  set.seed(123) 
  cv_f <- tryCatch(cv.glmnet(X, y, alpha=1, standardize=FALSE), error=function(e) NULL)
  if(!is.null(cv_f)){
    c <- as.matrix(coef(cv_f, s="lambda.min"))
    return(rownames(c)[c[,1] != 0 & rownames(c) != "(Intercept)"])
  } else return(character(0))
}

get_results_single_period <- function(file_path, target_crypto, method_name) {
  df <- read.csv(file_path)
  
  # Fjern uønskede klimavariabler
  df <- df %>%
    select(
      -contains("cpnews_index_narrow"),
      -contains("cpsent_index"),
      -contains("cpu_index_broad"),
      -contains("cpu_index_narrow")
    )
  
  # Y er den specifikke kryptovaluta
  y <- df[[target_crypto]]
  
  # X er alt andet 
  X_df <- df %>% 
    select(-Date) %>%
    select(-matches("Cleaned_BTC|Cleaned_ETH|Cleaned_LTC|Cleaned_XRP"))
  
  # Sikkerhedsrens (Fjerner NA og nul-varians)
  X_df <- X_df %>% 
    select(where(~ !any(is.na(.)))) %>% 
    select(where(~ sd(.) > 0))
  
  X_matrix <- as.matrix(X_df)
  selected_vars <- character(0)
  
  # Kører alle varianter baseret på method_name
  if(method_name == "LASSO") {
    selected_vars <- get_lasso_vars(X_matrix, y)
  } else if(method_name == "OCMT_1.0") { 
    selected_vars <- run_ocmt_safe(X_matrix, y, p_val = 0.05)
  } else if(method_name == "OCMT_0.5") {
    selected_vars <- run_ocmt_safe_0.5(X_matrix, y, p_val = 0.05)
  } else if(method_name == "OCMT_2.0") {
    selected_vars <- run_ocmt_safe_2.0(X_matrix, y, p_val = 0.05)
  } else if(method_name == "BMT_1.0") { 
    selected_vars <- run_bmt_safe(X_matrix, y, p_val = 0.05)
  } else if(method_name == "BMT_0.5") {
    selected_vars <- run_bmt_safe_0.5(X_matrix, y, p_val = 0.05)
  } else if(method_name == "BMT_2.0") {
    selected_vars <- run_bmt_safe_2.0(X_matrix, y, p_val = 0.05)
  }
  
  if(length(selected_vars) > 0) {
    selected_vars <- intersect(selected_vars, colnames(X_df)) 
    df_reg <- data.frame(y = y, X_df[, selected_vars, drop=FALSE])
    fit <- lm(y ~ ., data = df_reg)
    coefs <- summary(fit)$coefficients[-1, 1, drop=FALSE]
    return(data.frame(Variable = rownames(coefs), Coef = coefs[,1], stringsAsFactors = FALSE))
  } else {
    return(data.frame(Variable = character(0), Coef = numeric(0), stringsAsFactors = FALSE))
  }
}

# =========================================================================
# 3. KØR ANALYSEN FOR BEGGE KRYPTOER
# =========================================================================
# Definerer alle de modeller
modeller <- c("LASSO", "OCMT_1.0", "OCMT_0.5", "OCMT_2.0", "BMT_1.0", "BMT_0.5", "BMT_2.0")

# --- ETHEREUM ---
cat("\nBeregner modeller for ETHEREUM...\n")
eth_fil <- paste0(basis_sti, "MASTER_ETHEREUM_Full_Period.csv")
eth_results <- list()
for(m in modeller) {
  res <- get_results_single_period(eth_fil, "Cleaned_ETH", m)
  if(nrow(res) > 0) {
    res$Model <- m
    eth_results[[m]] <- res
  }
}

# --- RIPPLE ---
cat("\nBeregner modeller for RIPPLE...\n")
xrp_fil <- paste0(basis_sti, "MASTER_RIPPLE_Full_Period.csv")
xrp_results <- list()
for(m in modeller) {
  res <- get_results_single_period(xrp_fil, "Cleaned_XRP", m)
  if(nrow(res) > 0) {
    res$Model <- m
    xrp_results[[m]] <- res
  }
}

# =========================================================================
# 4. FORMATER OG UDSKRIV TABELLER
# =========================================================================
format_table <- function(res_list, krypto_navn) {
  df_all <- bind_rows(res_list)
  if(nrow(df_all) == 0) return(cat("Ingen variabler valgt for", krypto_navn, "i nogen modeller.\n"))
  
  # Formater tabellen, så modellerne er kolonner
  df_clean <- df_all %>%
    mutate(Variable = gsub("Cleaned_", "", Variable), Variable = gsub("_", " ", Variable)) %>%
    pivot_wider(names_from = Model, values_from = Coef)
  
  # Sikr at alle model-kolonner eksisterer, indsæt 0 for NA
  manglende <- setdiff(modeller, colnames(df_clean))
  if(length(manglende) > 0) { for(m in manglende) df_clean[[m]] <- NA }
  
  df_clean <- df_clean %>%
    select(Variable, all_of(modeller)) %>%
    mutate(across(-Variable, ~ sprintf("%.3f", as.numeric(.x)))) %>%
    mutate(across(-Variable, ~ ifelse(. == "NA", "0.000", .))) %>%
    arrange(Variable)
  
  cat("\n====================================================================================\n")
  cat(sprintf("--- %s : FULD PERIODE KOEFFICIENTER (ALLE MODELLER) ---\n", toupper(krypto_navn)))
  cat("====================================================================================\n")
  print(as.data.frame(df_clean), row.names = FALSE)
}

# Udskriv resultaterne
format_table(eth_results, "Ethereum")
format_table(xrp_results, "Ripple")


