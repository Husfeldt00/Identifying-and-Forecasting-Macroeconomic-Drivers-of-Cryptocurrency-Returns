# =========================================================================
# ROLLING WINDOW FORECAST (3 SETUPS: FULL, 2019, 2022) - ALLE DELTAER
# =========================================================================
library(dplyr)
library(glmnet)
library(lubridate)



# =========================================================================
# 1. LOAD DATA
# =========================================================================

source("00_paths.R")
basis_sti <- cleaned_sti

df_full <- read.csv(paste0(basis_sti, "MASTER_Full_Period.csv"))
df_full$Date <- as.Date(df_full$Date)

df_full <- df_full %>% arrange(Date) %>% na.omit()

# =========================================================================
# 2. LASSO FUNCTION
# =========================================================================
get_lasso_vars <- function(X, y) {
  X <- as.matrix(X)
  fit <- tryCatch(cv.glmnet(X, y, alpha = 1, standardize = FALSE),
                  error = function(e) NULL)
  
  if(!is.null(fit)) {
    coef_mat <- as.matrix(coef(fit, s = "lambda.min"))
    return(rownames(coef_mat)[coef_mat[,1] != 0 & rownames(coef_mat) != "(Intercept)"])
  } else return(character(0))
}

# =========================================================================
# 3. ROLLING FUNCTION
# =========================================================================
run_rolling <- function(df_full, start_date, label) {
  
  cat("\n====================================\n")
  cat("Running:", label, "\n")
  cat("====================================\n")
  
  end_date <- max(df_full$Date)
  current_train_start <- start_date
  
  all_predictions <- list()
  rul <- 1
  
  while(TRUE) {
    
    train_end <- current_train_start %m+% years(3)
    test_end  <- train_end %m+% months(3)
    
    if(train_end >= end_date) break
    if(test_end > end_date) test_end <- end_date
    
    df_train <- df_full %>% filter(Date >= current_train_start & Date < train_end)
    df_test  <- df_full %>% filter(Date >= train_end & Date < test_end)
    
    if(nrow(df_test) == 0) break
    
    y_train <- df_train$Cleaned_BTC
    X_train <- df_train %>% select(-Date, -Cleaned_BTC)
    
    X_train <- X_train %>% select(where(~ sd(.) > 0))
    X_mat <- as.matrix(X_train)
    
    # --- Variable selection for alle modeller ---
    vars_lasso    <- get_lasso_vars(X_train, y_train)
    vars_ocmt_1.0 <- run_ocmt_safe(X_mat, y_train, 0.05)
    vars_ocmt_0.5 <- run_ocmt_safe_0.5(X_mat, y_train, 0.05)
    vars_ocmt_2.0 <- run_ocmt_safe_2.0(X_mat, y_train, 0.05)
    
    vars_bmt_1.0  <- run_bmt_safe(X_mat, y_train, 0.05)
    vars_bmt_0.5  <- run_bmt_safe_0.5(X_mat, y_train, 0.05)
    vars_bmt_2.0  <- run_bmt_safe_2.0(X_mat, y_train, 0.05)
    
    # --- Forecast funktion ---
    forecast_model <- function(name, vars) {
      if(length(vars) > 0) {
        valid_vars <- intersect(vars, colnames(X_train))
        df_reg_train <- data.frame(y = y_train, X_train[, valid_vars, drop=FALSE])
        df_reg_test <- data.frame(df_test[, valid_vars, drop=FALSE])
      } else {
        df_reg_train <- data.frame(y = y_train)
        df_reg_test  <- data.frame(matrix(nrow=nrow(df_test), ncol=0))
      }
      
      fit <- lm(y ~ ., data = df_reg_train)
      pred <- predict(fit, newdata = df_reg_test)
      
      data.frame(
        Date = df_test$Date,
        Actual = df_test$Cleaned_BTC,
        Pred = pred,
        Model = name
      )
    }
    
    # --- Kør forecast for alle modeller ---
    all_predictions[[paste0("Mean_",rul)]]     <- forecast_model("1. Mean Model", character(0))
    all_predictions[[paste0("LASSO_",rul)]]    <- forecast_model("2. LASSO", vars_lasso)
    all_predictions[[paste0("OCMT_1.0_",rul)]] <- forecast_model("3. OCMT (delta=1.0)", vars_ocmt_1.0)
    all_predictions[[paste0("OCMT_0.5_",rul)]] <- forecast_model("4. OCMT (delta=0.5)", vars_ocmt_0.5)
    all_predictions[[paste0("OCMT_2.0_",rul)]] <- forecast_model("5. OCMT (delta=2.0)", vars_ocmt_2.0)
    all_predictions[[paste0("BMT_1.0_",rul)]]  <- forecast_model("6. BMT (delta=1.0)", vars_bmt_1.0)
    all_predictions[[paste0("BMT_0.5_",rul)]]  <- forecast_model("7. BMT (delta=0.5)", vars_bmt_0.5)
    all_predictions[[paste0("BMT_2.0_",rul)]]  <- forecast_model("8. BMT (delta=2.0)", vars_bmt_2.0)
    
    current_train_start <- current_train_start %m+% months(3)
    rul <- rul + 1
  }
  
  # =========================================================================
  # EVALUATION
  # =========================================================================
  df_results <- bind_rows(all_predictions)
  
  metrics <- df_results %>%
    mutate(error_sq = (Actual - Pred)^2) %>%
    group_by(Model) %>%
    summarise(MSFE = mean(error_sq))
  
  msfe_bench <- metrics %>% filter(Model == "1. Mean Model") %>% pull(MSFE)
  
  metrics <- metrics %>%
    mutate(R2_OOS = (1 - MSFE / msfe_bench) * 100)
  
  return(metrics)
}

# =========================================================================
# 4. RUN 3 SETUPS
# =========================================================================
# 1. FULL SAMPLE
res_full <- run_rolling(df_full, min(df_full$Date), "Full Sample")

# 2. START 2019 (Første forecast i 2019)
start_2019 <- as.Date("2016-01-01")  # 3 år før 2019
res_2019 <- run_rolling(df_full, start_2019, "Rolling from 2019")

# 3. START 2022 (Første forecast i 2022)
start_2022 <- as.Date("2019-01-01")  # 3 år før 2022
res_2022 <- run_rolling(df_full, start_2022, "Rolling from 2022")

# =========================================================================
# 5. SAMLET TABEL
# =========================================================================
final_table <- res_full %>%
  rename(MSFE_Full = MSFE, R2_Full = R2_OOS) %>%
  left_join(
    res_2019 %>% rename(MSFE_2019 = MSFE, R2_2019 = R2_OOS),
    by = "Model"
  ) %>%
  left_join(
    res_2022 %>% rename(MSFE_2022 = MSFE, R2_2022 = R2_OOS),
    by = "Model"
  )

# Pæn afrunding
final_table_print <- final_table %>%
  mutate(across(starts_with("MSFE"), ~ sprintf("%.5f", .))) %>%
  mutate(across(starts_with("R2"), ~ sprintf("%.3f %%", .)))

cat("\n=====================================================================\n")
cat("FINAL COMPARISON TABLE (FULL vs. 2019 vs. 2022)\n")
cat("=====================================================================\n")
print(as.data.frame(final_table_print), row.names = FALSE)
cat("=====================================================================\n")