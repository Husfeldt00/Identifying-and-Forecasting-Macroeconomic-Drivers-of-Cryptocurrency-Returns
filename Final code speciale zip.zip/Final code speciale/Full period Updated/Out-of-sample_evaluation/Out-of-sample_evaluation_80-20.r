# =========================================================================
# OUT-OF-SAMPLE FORECASTING (80/20 SPLIT) kun makro
# =========================================================================
library(dplyr)
library(tidyr)
library(glmnet)



# 1. Indlæs data

source("00_paths.R")
basis_sti <- cleaned_sti

fuld_fil_sti <- paste0(basis_sti, "MASTER_Full_Period.csv")

df_full <- read.csv(fuld_fil_sti)
df_full$Date <- as.Date(df_full$Date)

df_full <- df_full %>% arrange(Date) %>% na.omit()

# 2. 80/20 SPLIT
N_total <- nrow(df_full)
N_train <- floor(0.80 * N_total)

df_train <- df_full[1:N_train, ]
df_test  <- df_full[(N_train + 1):N_total, ]

cat(sprintf("Datasæt delt: Træner på %d dage. Tester på %d dage.\n", 
            N_train, nrow(df_test)))

# 3. DATA TIL MODELLER
y_train <- df_train$Cleaned_BTC
X_macro_train <- df_train %>% select(-Date, -Cleaned_BTC)

# 4. VARIABLE SELECTION

## LASSO (uden lag)
get_lasso_vars <- function(X_mac, y_target) {
  X_matrix <- as.matrix(X_mac)
  cv_f <- tryCatch(cv.glmnet(X_matrix, y_target, alpha=1, standardize=FALSE),
                   error=function(e) NULL)
  if(!is.null(cv_f)){
    c <- as.matrix(coef(cv_f, s="lambda.min"))
    return(rownames(c)[c[,1] != 0 & rownames(c) != "(Intercept)"])
  } else return(character(0))
}

vars_ar1   <- character(0)
vars_lasso <- get_lasso_vars(X_macro_train, y_train)
vars_ocmt  <- run_ocmt_safe(as.matrix(X_macro_train), y_train, 0.05)
vars_bmt   <- run_bmt_safe(as.matrix(X_macro_train), y_train, 0.05)

# 5. FORECAST FUNKTION
forecast_oos <- function(navn, valgte_makro) {

  # A. TRÆNING
  if(length(valgte_makro) > 0) {
    valgte_gyldige <- intersect(valgte_makro, colnames(X_macro_train))
    df_reg_train <- data.frame(y = y_train, 
                               X_macro_train[, valgte_gyldige, drop=FALSE])
  } else {
    df_reg_train <- data.frame(y = y_train)
  }

  fit_train <- lm(y ~ ., data = df_reg_train)

  # B. TEST
  if(length(valgte_makro) > 0) {
    df_reg_test <- data.frame(df_test[, valgte_gyldige, drop=FALSE])
  } else {
    df_reg_test <- data.frame(matrix(nrow=nrow(df_test), ncol=0))
  }

  y_hat_test <- predict(fit_train, newdata = df_reg_test)

  # C. FEJL
  e_test <- df_test$Cleaned_BTC - y_hat_test
  msfe <- mean(e_test^2)
  rmsfe <- sqrt(msfe)

  return(list(
    Navn = navn,
    Antal_Valgte = length(valgte_makro),
    MSFE = msfe,
    RMSFE = rmsfe
  ))
}

# 6. KØR MODELLER
res_ar1   <- forecast_oos("1. Mean Model (No predictors)", vars_ar1)
res_lasso <- forecast_oos("2. LASSO", vars_lasso)
res_ocmt  <- forecast_oos("3. OCMT", vars_ocmt)
res_bmt   <- forecast_oos("4. BMT", vars_bmt)

# 7. R2_OOS
msfe_benchmark <- res_ar1$MSFE

byg_række <- function(res) {
  r2_oos <- 1 - (res$MSFE / msfe_benchmark)
  data.frame(
    Model = res$Navn,
    Makro_Variabler_Valgt = res$Antal_Valgte,
    RMSFE = res$RMSFE,
    R2_OOS_pct = r2_oos * 100
  )
}

tabel_oos <- bind_rows(
  byg_række(res_ar1),
  byg_række(res_lasso),
  byg_række(res_ocmt),
  byg_række(res_bmt)
)

cat("\n=======================================================\n")
cat(" OUT-OF-SAMPLE FORECASTING (UDEN LAG)\n")
cat(" Benchmark: Mean Model\n")
cat("=======================================================\n")

print(tabel_oos %>% 
        mutate(
          RMSFE = sprintf("%.5f", RMSFE),
          R2_OOS_pct = sprintf("%.3f %%", R2_OOS_pct)
        ))

cat("=======================================================\n")

cat("Variabler valgt af BMT: ", paste(vars_bmt, collapse = ", "), "\n")
cat("Variabler valgt af OCMT: ", paste(vars_ocmt, collapse = ", "), "\n")
cat("Variabler valgt af LASSO: ", paste(vars_lasso, collapse = ", "), "\n")

cat("Sidste dato i træningssættet (slut 80%):", as.character(max(df_train$Date)), "\n")
