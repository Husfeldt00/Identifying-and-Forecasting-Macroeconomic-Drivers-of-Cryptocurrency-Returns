# =========================================================================
# ROLLING WINDOW FORECAST - MULTIPLE CRYPTO (3 SETUPS, 8 MODELLER)
# =========================================================================
library(dplyr)
library(glmnet)
library(lubridate)



# =========================================================================
# 1. FILER + TARGETS
# =========================================================================

source("00_paths.R")
basis_sti <- cleaned_sti


krypto_liste <- list(
  Litecoin = list(fil = "MASTER_LITECOIN_Full_Period.csv", target = "Cleaned_LTC"),
  Ethereum = list(fil = "MASTER_ETHEREUM_Full_Period.csv", target = "Cleaned_ETH"),
  Ripple   = list(fil = "MASTER_RIPPLE_Full_Period.csv",   target = "Cleaned_XRP")
)

# =========================================================================
# 2. LASSO FUNCTION
# =========================================================================
get_lasso_vars <- function(X, y) {
  set.seed(123)
  X <- as.matrix(X)
  fit <- tryCatch(cv.glmnet(X, y, alpha = 1, standardize = FALSE),
                  error = function(e) NULL)
  
  if(!is.null(fit)) {
    coef_mat <- as.matrix(coef(fit, s = "lambda.min"))
    return(rownames(coef_mat)[coef_mat[,1] != 0 & rownames(coef_mat) != "(Intercept)"])
  } else return(character(0))
}

# =========================================================================
# 3. ROLLING FUNCTION 
# =========================================================================
run_rolling <- function(df_full, target_col, start_date, label) {
  
  cat("   -> Running:", label, "\n")
  
  df_full <- df_full %>% arrange(Date) %>% na.omit()
  
  
  if(start_date < min(df_full$Date)) {
    start_date <- min(df_full$Date)
  }
  
  end_date   <- max(df_full$Date)
  current_train_start <- start_date
  
  all_predictions <- list()
  rul <- 1
  
  while(TRUE) {
    
    train_end <- current_train_start %m+% years(3)
    test_end  <- train_end %m+% months(3)
    
    if(train_end >= end_date) break
    if(test_end > end_date) test_end <- end_date
    
    df_train <- df_full %>% filter(Date >= current_train_start & Date < train_end)
    df_test  <- df_full %>% filter(Date >= train_end & Date < test_end)
    
    if(nrow(df_test) == 0) break
    
    y_train <- df_train[[target_col]]
    X_train <- df_train %>% select(-Date, -all_of(target_col))
    
    X_train <- X_train %>% select(where(~ sd(.) > 0))
    X_mat <- as.matrix(X_train)
    
    # --- Variable selection (Alle 8 setups) ---
    vars_lasso    <- get_lasso_vars(X_train, y_train)
    
    vars_ocmt_1.0 <- run_ocmt_safe(X_mat, y_train, 0.05)
    vars_ocmt_0.5 <- run_ocmt_safe_0.5(X_mat, y_train, 0.05)
    vars_ocmt_2.0 <- run_ocmt_safe_2.0(X_mat, y_train, 0.05)
    
    vars_bmt_1.0  <- run_bmt_safe(X_mat, y_train, 0.05)
    vars_bmt_0.5  <- run_bmt_safe_0.5(X_mat, y_train, 0.05)
    vars_bmt_2.0  <- run_bmt_safe_2.0(X_mat, y_train, 0.05)
    
    # --- Forecast Model Funktion ---
    forecast_model <- function(name, vars) {
      if(length(vars) > 0) {
        valid_vars <- intersect(vars, colnames(X_train))
        df_reg_train <- data.frame(y = y_train, X_train[, valid_vars, drop=FALSE])
        df_reg_test <- data.frame(df_test[, valid_vars, drop=FALSE])
      } else {
        df_reg_train <- data.frame(y = y_train)
        df_reg_test  <- data.frame(matrix(nrow=nrow(df_test), ncol=0))
      }
      
      fit <- lm(y ~ ., data = df_reg_train)
      pred <- predict(fit, newdata = df_reg_test)
      
      data.frame(
        Date = df_test$Date,
        Actual = df_test[[target_col]],
        Pred = pred,
        Model = name
      )
    }
    
    # --- Kør modeller ---
    all_predictions[[paste0("Mean_",rul)]]     <- forecast_model("1. Mean Model", character(0))
    all_predictions[[paste0("LASSO_",rul)]]    <- forecast_model("2. LASSO", vars_lasso)
    all_predictions[[paste0("OCMT_1.0_",rul)]] <- forecast_model("3. OCMT (delta=1.0)", vars_ocmt_1.0)
    all_predictions[[paste0("OCMT_0.5_",rul)]] <- forecast_model("4. OCMT (delta=0.5)", vars_ocmt_0.5)
    all_predictions[[paste0("OCMT_2.0_",rul)]] <- forecast_model("5. OCMT (delta=2.0)", vars_ocmt_2.0)
    all_predictions[[paste0("BMT_1.0_",rul)]]  <- forecast_model("6. BMT (delta=1.0)", vars_bmt_1.0)
    all_predictions[[paste0("BMT_0.5_",rul)]]  <- forecast_model("7. BMT (delta=0.5)", vars_bmt_0.5)
    all_predictions[[paste0("BMT_2.0_",rul)]]  <- forecast_model("8. BMT (delta=2.0)", vars_bmt_2.0)
    
    current_train_start <- current_train_start %m+% months(3)
    rul <- rul + 1
  }
  
  # ============================
  # EVALUATION
  # ============================
  df_results <- bind_rows(all_predictions)
  
  metrics <- df_results %>%
    mutate(error_sq = (Actual - Pred)^2) %>%
    group_by(Model) %>%
    summarise(
      MSFE = mean(error_sq),
      .groups = "drop"
    )
  
  msfe_bench <- metrics %>% filter(Model == "1. Mean Model") %>% pull(MSFE)
  
  metrics <- metrics %>%
    mutate(R2_OOS = (1 - MSFE / msfe_bench) * 100)
  
  return(metrics)
}

# =========================================================================
# 4. MAIN LOOP FOR MULTIPLE CRYPTO & MULTIPLE SETUPS
# =========================================================================
all_final_tables <- list()

for (krypto_navn in names(krypto_liste)) {
  
  cat("\n=======================================================\n")
  cat(sprintf(" STARTER ANALYSE FOR: %s \n", toupper(krypto_navn)))
  cat("=======================================================\n")
  
  filnavn <- krypto_liste[[krypto_navn]]$fil
  target  <- krypto_liste[[krypto_navn]]$target
  
  df <- read.csv(paste0(basis_sti, filnavn))
  df$Date <- as.Date(df$Date)
  
  # A. FULL SAMPLE
  res_full <- run_rolling(df, target, min(df$Date), paste(krypto_navn, "- Full Sample"))
  
  # B. START 2019 (Første forecast i 2019 -> Træning starter i 2016)
  start_2019 <- as.Date("2016-01-01") 
  res_2019   <- run_rolling(df, target, start_2019, paste(krypto_navn, "- 2019"))
  
  # C. START 2022 (Første forecast i 2022 -> Træning starter i 2019)
  start_2022 <- as.Date("2019-01-01") 
  res_2022   <- run_rolling(df, target, start_2022, paste(krypto_navn, "- 2022"))
  
  # D. SAML TABELLEN FOR DENNE KRYPTOVALUTA
  final_table_krypto <- res_full %>%
    rename(MSFE_Full = MSFE, R2_Full = R2_OOS) %>%
    left_join(res_2019 %>% rename(MSFE_2019 = MSFE, R2_2019 = R2_OOS), by = "Model") %>%
    left_join(res_2022 %>% rename(MSFE_2022 = MSFE, R2_2022 = R2_OOS), by = "Model") %>%
    mutate(Asset = krypto_navn) %>%
    relocate(Asset) # Sætter Asset-kolonnen forrest
  
  all_final_tables[[krypto_navn]] <- final_table_krypto
}

# =========================================================================
# 5. FINAL TABLE OUTPUT
# =========================================================================
final_results <- bind_rows(all_final_tables)

# Pæn afrunding
final_table_print <- final_results %>%
  mutate(across(starts_with("MSFE"), ~ sprintf("%.5f", .))) %>%
  mutate(across(starts_with("R2"), ~ sprintf("%.3f %%", .)))

cat("\n===================================================================================================\n")
cat("FINAL COMPARISON TABLE FOR ALL CRYPTOS (FULL vs. 2019 vs. 2022)\n")
cat("===================================================================================================\n")
print(as.data.frame(final_table_print), row.names = FALSE)
cat("===================================================================================================\n")