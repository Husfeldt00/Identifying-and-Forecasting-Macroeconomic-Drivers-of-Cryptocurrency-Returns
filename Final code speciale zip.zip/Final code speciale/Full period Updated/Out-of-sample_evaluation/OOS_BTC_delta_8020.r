# =========================================================================
# OUT-OF-SAMPLE FORECASTING (80/20 SPLIT) kun makro - ALLE DELTA VÆRDIER
# =========================================================================
library(dplyr)
library(tidyr)
library(glmnet)


# 1. Indlæs data

source("00_paths.R")
basis_sti <- cleaned_sti

fuld_fil_sti <- paste0(basis_sti, "MASTER_Full_Period.csv")

df_full <- read.csv(fuld_fil_sti)
df_full$Date <- as.Date(df_full$Date)

df_full <- df_full %>% arrange(Date) %>% na.omit()

# 2. 80/20 SPLIT
N_total <- nrow(df_full)
N_train <- floor(0.80 * N_total)

df_train <- df_full[1:N_train, ]
df_test  <- df_full[(N_train + 1):N_total, ]

cat(sprintf("Datasæt delt: Træner på %d dage. Tester på %d dage.\n", 
            N_train, nrow(df_test)))

# 3. DATA TIL MODELLER
y_train <- df_train$Cleaned_BTC
X_macro_train <- df_train %>% select(-Date, -Cleaned_BTC)

# 4. VARIABLE SELECTION

## LASSO (uden lag)
get_lasso_vars <- function(X_mac, y_target) {
  X_matrix <- as.matrix(X_mac)
  cv_f <- tryCatch(cv.glmnet(X_matrix, y_target, alpha=1, standardize=FALSE),
                   error=function(e) NULL)
  if(!is.null(cv_f)){
    c <- as.matrix(coef(cv_f, s="lambda.min"))
    return(rownames(c)[c[,1] != 0 & rownames(c) != "(Intercept)"])
  } else return(character(0))
}

# Hent udvalgte variabler for alle modeller
X_mat <- as.matrix(X_macro_train)

vars_ar1      <- character(0)
vars_lasso    <- get_lasso_vars(X_macro_train, y_train)

# OCMT med forskellige delta
vars_ocmt_1.0 <- run_ocmt_safe(X_mat, y_train, p_val = 0.05)
vars_ocmt_0.5 <- run_ocmt_safe_0.5(X_mat, y_train, p_val = 0.05)
vars_ocmt_2.0 <- run_ocmt_safe_2.0(X_mat, y_train, p_val = 0.05)

# BMT med forskellige delta
vars_bmt_1.0  <- run_bmt_safe(X_mat, y_train, p_val = 0.05)
vars_bmt_0.5  <- run_bmt_safe_0.5(X_mat, y_train, p_val = 0.05)
vars_bmt_2.0  <- run_bmt_safe_2.0(X_mat, y_train, p_val = 0.05)

# 5. FORECAST FUNKTION
forecast_oos <- function(navn, valgte_makro) {

  # A. TRÆNING
  if(length(valgte_makro) > 0) {
    valgte_gyldige <- intersect(valgte_makro, colnames(X_macro_train))
    df_reg_train <- data.frame(y = y_train, 
                               X_macro_train[, valgte_gyldige, drop=FALSE])
  } else {
    df_reg_train <- data.frame(y = y_train)
  }

  fit_train <- lm(y ~ ., data = df_reg_train)

  # B. TEST
  if(length(valgte_makro) > 0) {
    df_reg_test <- data.frame(df_test[, valgte_gyldige, drop=FALSE])
  } else {
    df_reg_test <- data.frame(matrix(nrow=nrow(df_test), ncol=0))
  }

  y_hat_test <- predict(fit_train, newdata = df_reg_test)

  # C. FEJL
  e_test <- df_test$Cleaned_BTC - y_hat_test
  msfe <- mean(e_test^2)

  return(list(
    Navn = navn,
    Antal_Valgte = length(valgte_makro),
    MSFE = msfe
  ))
}

# 6. KØR MODELLER
res_ar1       <- forecast_oos("1. Mean Model", vars_ar1)
res_lasso     <- forecast_oos("2. LASSO", vars_lasso)
res_ocmt_1.0  <- forecast_oos("3. OCMT (delta=1.0)", vars_ocmt_1.0)
res_ocmt_0.5  <- forecast_oos("4. OCMT (delta=0.5)", vars_ocmt_0.5)
res_ocmt_2.0  <- forecast_oos("5. OCMT (delta=2.0)", vars_ocmt_2.0)
res_bmt_1.0   <- forecast_oos("6. BMT (delta=1.0)", vars_bmt_1.0)
res_bmt_0.5   <- forecast_oos("7. BMT (delta=0.5)", vars_bmt_0.5)
res_bmt_2.0   <- forecast_oos("8. BMT (delta=2.0)", vars_bmt_2.0)

# 7. R2_OOS
msfe_benchmark <- res_ar1$MSFE

byg_række <- function(res) {
  r2_oos <- 1 - (res$MSFE / msfe_benchmark)
  data.frame(
    Model = res$Navn,
    Makro_Variabler_Valgt = res$Antal_Valgte,
    MSFE = res$MSFE,
    R2_OOS_pct = r2_oos * 100
  )
}

tabel_oos <- bind_rows(
  byg_række(res_ar1),
  byg_række(res_lasso),
  byg_række(res_ocmt_1.0),
  byg_række(res_ocmt_0.5),
  byg_række(res_ocmt_2.0),
  byg_række(res_bmt_1.0),
  byg_række(res_bmt_0.5),
  byg_række(res_bmt_2.0)
)

cat("\n=======================================================\n")
cat(" OUT-OF-SAMPLE FORECASTING (UDEN LAG)\n")
cat(" Benchmark: Mean Model\n")
cat("=======================================================\n")

print(tabel_oos %>% 
        mutate(
          MSFE = sprintf("%.5f", MSFE),
          R2_OOS_pct = sprintf("%.3f %%", R2_OOS_pct)
        ))

cat("\n=======================================================\n")
cat("VALGTE VARIABLER I TRÆNINGSPERIODEN (80%)\n")
cat("=======================================================\n")
cat("LASSO:            ", paste(vars_lasso, collapse = ", "), "\n")
cat("OCMT (delta=1.0): ", paste(vars_ocmt_1.0, collapse = ", "), "\n")
cat("OCMT (delta=0.5): ", paste(vars_ocmt_0.5, collapse = ", "), "\n")
cat("OCMT (delta=2.0): ", paste(vars_ocmt_2.0, collapse = ", "), "\n")
cat("BMT (delta=1.0):  ", paste(vars_bmt_1.0, collapse = ", "), "\n")
cat("BMT (delta=0.5):  ", paste(vars_bmt_0.5, collapse = ", "), "\n")
cat("BMT (delta=2.0):  ", paste(vars_bmt_2.0, collapse = ", "), "\n")
cat("\nSidste dato i træningssættet (slut 80%):", as.character(max(df_train$Date)), "\n")
