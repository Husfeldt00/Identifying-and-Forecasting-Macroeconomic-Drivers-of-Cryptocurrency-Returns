# =========================================================================
# SCRIPT 3: RENSNING AF GULD (GOLD NY FUTURES) - KUN LOG-AFKAST
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af Guld (NY Futures)...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/Gold Futures Historical Data_NY.csv"

# 2. Indlæs data 
gold_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# Automatisk håndtering af kolonnenavne (sikrer at uanset om den hedder Price eller Close, bliver den til Value)
if("Price" %in% colnames(gold_raw)) {
  gold_raw <- gold_raw %>% rename(Value = Price)
} else if("Close" %in% colnames(gold_raw)) {
  gold_raw <- gold_raw %>% rename(Value = Close)
}

# 3. Formater datoer og forbered data
gold_clean <- gold_raw %>%
  mutate(
    # Fanger datoformatet dmy (dag-måned-år), mdy eller ymd
    Date = as.Date(parse_date_time(Date, orders = c("dmy", "mdy", "ymd"))),
    
    # Fjerner amerikanske tusindtals-kommaer (fx 1,950.00 -> 1950.00) før den gøres numerisk
    Value_clean = gsub(",", "", Value),
    Close = as.numeric(Value_clean)
  ) %>%
  select(Date, Close) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
gold_final <- gold_clean %>%
  mutate(
    # Logaritmiske afkast (kontinuerlig forrentning)
    Cleaned_GOLD = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_GOLD) %>%
  na.omit() # Fjerner første række, som bliver NA pga. lag()

# 5. Gem resultatet (Vi gemmer den som Cleaned_GOLD_NY.csv)
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_GOLD_NY.csv"
write.csv(gold_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset Guld-data (KUN log-afkast):\n")
print(head(gold_final))
cat("\n✅ SUCCESS: Guld er renset og gemt! Klar til at blive flettet i Master Scriptet.\n")
