# =========================================================================
# SCRIPT 22: RENSNING AF MSCI EUROPE (KUN LOG-AFKAST)
# =========================================================================
library(dplyr)
library(lubridate) # 'zoo' er fjernet, da interpolationen klares af Master Scriptet

print("Starter rensning og splejsning af MSCI Europe...")

# 1. Definer stier til dine TO RAW filer (Opdateret med "Updated")
fil_sti_monthly <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/MSCI_monthly_full_period.csv"
fil_sti_daily   <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/MSCI Europe Historical Data.csv"

# 2. Indlæs begge filer
msci_monthly_raw <- read.csv(fil_sti_monthly, stringsAsFactors = FALSE)
msci_daily_raw   <- read.csv(fil_sti_daily, stringsAsFactors = FALSE)

# 3. Rens den DAGLIGE data først (Investing.com format)
msci_daily <- msci_daily_raw %>%
  mutate(
    Date = as.Date(parse_date_time(Date, orders = c("mdy", "dmy", "ymd"))),
    Close = as.numeric(gsub(",", "", Price))
  ) %>%
  select(Date, Close) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# Find ud af hvornår den daglige data starter
start_paa_daglig <- min(msci_daily$Date)
print(paste("Den daglige data starter:", start_paa_daglig))

# 4. Rens den MÅNEDLIGE data (Format "MM/YYYY")
msci_monthly <- msci_monthly_raw %>%
  mutate(
    # lubridate's "my()" funktion forstår automatisk Måned/År og sætter dagen til d. 1.
    Date = as.Date(my(Date)),
    # R omdøber typisk kolonner med mellemrum ved at sætte punktum ind: MSCI.Europe
    Close = as.numeric(MSCI.Europe)
  ) %>%
  select(Date, Close) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close)) %>%
  # VIGTIGT: Vi beholder kun den månedlige data, der ligger FØR den daglige data starter!
  filter(Date < start_paa_daglig)

# 5. Splejs de to datasæt sammen!
msci_kombineret <- bind_rows(msci_monthly, msci_daily) %>%
  arrange(Date)

# 6. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
msci_final <- msci_kombineret %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference regnet på den splejsede serie
    Cleaned_MSCI = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_MSCI) %>%
  na.omit() # Fjerner den allerførste observation (NA pga. lag)

# 7. Gem resultatet direkte i din opdaterede Cleaned_CSV mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_MSCI.csv"
write.csv(msci_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset og splejset MSCI Europe-data:\n")
print(head(msci_final))
cat("\n✅ SUCCESS: MSCI Europe er splejset, renset (kun log-afkast) og gemt i Cleaned_CSV.\n")