# =========================================================================
# THE MASTER SCRIPT: SAMLING, INTERPOLATION, SMOOTHING OG STANDARDISERING
# =========================================================================
# install.packages("zoo")
# install.packages("readr")
library(dplyr)
library(purrr)
library(zoo)
library(readr)



# 1. Definer stien til din mappe med alle de rensede filer

source("00_paths.R")
basis_sti <- cleaned_sti


# 2. Find alle CSV-filer i mappen, der starter med "Cleaned_"
alle_filer <- list.files(path = basis_sti, pattern = "^Cleaned_.*\\.csv$", full.names = TRUE)

print(paste("Fandt", length(alle_filer), "rensede filer. Samler dem nu..."))

# 3. Indlæs alle filer og flet dem sammen på kolonnen 'Date'
# reduce + full_join sørger for, at vi får ét kæmpe datasæt med alle variabler
master_raw <- alle_filer %>%
  map(read.csv) %>%
  reduce(full_join, by = "Date") %>%
  mutate(Date = as.Date(Date)) %>%
  arrange(Date)

# 4. Skab den ultimative kalender fra start til slut (Full Period)
start_dato <- as.Date("2010-07-24")
slut_dato  <- as.Date("2024-12-31")
master_kalender <- data.frame(Date = seq(start_dato, slut_dato, by = "days"))

# 5. Flet vores master data på kalenderen og interpoler
master_interp <- master_kalender %>%
  left_join(master_raw, by = "Date") %>%
  # Vi fylder weekender og helligdage ud
  mutate(
    across(
      # Vi bruger na.locf (fremadrettet kopiering) til renterne, da de ændres i trin
      c(any_of("Cleaned_FED"), any_of("Cleaned_ECB"), any_of("Cleaned_TREAS")), 
      ~ na.locf(.x, na.rm = FALSE)
    ),
    across(
      # Vi bruger na.approx (lineær tråd) til ALLE andre kolonner (aktier, valuta, krypto)
      -c(Date, any_of("Cleaned_FED"), any_of("Cleaned_ECB"), any_of("Cleaned_TREAS")), 
      ~ na.approx(.x, na.rm = FALSE, rule = 2)
    )
  )

# 6. Matematik: 2-dages glidende gennemsnit (KUN FOR NON-RENTER)
renter <- c("Cleaned_FED", "Cleaned_ECB", "Cleaned_TREAS")

master_smoothed <- master_interp %>%
  mutate(
    across(
      # Tag glidende gennemsnit af alt, undtagen Date og Renterne
      -c(Date, any_of(renter)),
      ~ rollmean(.x, k = 2, fill = NA, align = "right")
    )
  ) %>%
  # Fjerner de rækker der mangler data (fx pga lag, rolling average eller rullende skewness)
  na.omit() 

print("Data er samlet, interpoleret og smoothed. Klipper nu over i perioder og standardiserer...")

# 7. Definer en smart funktion der klipper, standardiserer og gemmer
slice_and_scale <- function(df, start, slut, filnavn) {
  # Klip perioden ud
  sliced_df <- df %>%
    filter(Date >= as.Date(start) & Date <= as.Date(slut))
  
  # Standardiser variablerne INTERNT i perioden (Mean=0, Var=1)
  scaled_df <- sliced_df %>%
    mutate(
      across(-Date, ~ as.numeric(scale(.x)))
    )
  
  # Gem filen
  gem_sti <- paste0(basis_sti, "MASTER_", filnavn, ".csv")
  write.csv(scaled_df, gem_sti, row.names = FALSE)
  
  print(paste("✅ Oprettet", filnavn, "med", nrow(scaled_df), "observationer."))
}

# 8. Kør funktionen på dine 5 perioder
slice_and_scale(master_smoothed, "2010-07-24", "2024-12-31", "Full_Period")
slice_and_scale(master_smoothed, "2010-07-24", "2013-10-01", "P1")
slice_and_scale(master_smoothed, "2013-10-02", "2017-01-03", "P2")
slice_and_scale(master_smoothed, "2017-01-04", "2017-06-23", "P3")
slice_and_scale(master_smoothed, "2017-06-24", "2024-12-31", "P4")

