# =========================================================================
# SCRIPT 11: RENSNING AF NASDAQ - KUN LOG-AFKAST
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af NASDAQ...")

# 1. Definer stien til din RAW fil (Opdateret med "Updated")
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/NASDAQ Composite Historical Data (1).csv"

# 2. Indlæs data
nasdaq_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og rens priser
nasdaq_clean <- nasdaq_raw %>%
  mutate(
    # Fanger formatet "MM/DD/YYYY"
    Date = as.Date(parse_date_time(Date, orders = c("mdy", "dmy", "ymd"))),
    # Fjerner tusindtalskommaer og konverterer til tal
    Close = as.numeric(gsub(",", "", Price))
  ) %>%
  # Vi fjerner blanke "fake" weekender/helligdage uden volumen, 
  # så Master Scriptet har et helt rent grundlag for sin interpolation bagefter.
  filter(Vol. != "") %>%
  select(Date, Close) %>%
  # Sorterer kronologisk
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
nasdaq_final <- nasdaq_clean %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_NASDAQ = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_NASDAQ) %>%
  na.omit() # Fjerner den første observation (NA pga. lag)

# 5. Gem resultatet direkte i din opdaterede Cleaned_CSV mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_NASDAQ.csv"
write.csv(nasdaq_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset NASDAQ-data:\n")
print(head(nasdaq_final))
cat("\n✅ SUCCESS: NASDAQ er renset (kun log-afkast) og gemt i Cleaned_CSV mappen.\n")
