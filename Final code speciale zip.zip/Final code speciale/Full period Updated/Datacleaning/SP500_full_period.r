# =========================================================================
# SCRIPT 21: RENSNING AF S&P 500 - KUN LOG-AFKAST
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af S&P 500...")

# 1. Definer stien til din RAW fil (Opdateret med "Updated")
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/S&P 500 Historical Data.csv"

# 2. Indlæs data
sp500_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og rens priser
sp500_clean <- sp500_raw %>%
  mutate(
    # Fanger formatet "MM/DD/YYYY"
    Date = as.Date(parse_date_time(Date, orders = c("mdy", "dmy", "ymd"))),
    # Fjerner tusindtalskommaer og konverterer til tal
    Close = as.numeric(gsub(",", "", Price))
  ) %>%
  select(Date, Close) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
sp500_final <- sp500_clean %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_SP500 = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_SP500) %>%
  na.omit() # Fjerner den første observation (NA pga. lag)

# 5. Gem resultatet i din Cleaned_CSV mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_SP500.csv"
write.csv(sp500_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset S&P 500-data:\n")
print(head(sp500_final))
cat("\n✅ SUCCESS: S&P 500 er renset (kun log-afkast) og gemt i Cleaned_CSV mappen.\n")