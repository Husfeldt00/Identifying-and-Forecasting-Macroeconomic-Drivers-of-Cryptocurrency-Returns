# =========================================================================
# SCRIPT 8: RENSNING AF CNY/USD - KUN LOG-AFKAST
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af CNY/USD...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/CNY_USD Historical Data.csv"

# 2. Indlæs data
cny_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og rens tal
cny_clean <- cny_raw %>%
  mutate(
    # Fanger formatet "MM/DD/YYYY" (eller lignende)
    Date = as.Date(parse_date_time(Date, orders = c("mdy", "dmy", "ymd"))),
    # Fanger prisen. Fjerner evt. kommaer fra store tal for at undgå NA
    Close = as.numeric(gsub(",", "", Price))
  ) %>%
  select(Date, Close) %>%
  # VIGTIGT: Sorterer kronologisk, da rådataen ofte er baglæns
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
cny_final <- cny_clean %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_CNY = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_CNY) %>%
  na.omit() # Fjerner den første observation (NA pga. lag)

# 5. Gem resultatet i din Cleaned_CSV mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_CNY.csv"
write.csv(cny_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset CNY/USD-data:\n")
print(tail(cny_final))
cat("\n✅ SUCCESS: CNY/USD er renset (kun log-afkast) og gemt i Cleaned_CSV mappen.\n")
