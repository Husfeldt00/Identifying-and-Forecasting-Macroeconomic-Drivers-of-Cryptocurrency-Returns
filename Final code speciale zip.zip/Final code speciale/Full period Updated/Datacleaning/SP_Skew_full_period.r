# =========================================================================
# SCRIPT 30: BEREGN RULLENDE SKEWNESS FOR S&P 500 (UDEN GLOBAL SKALERING)
# =========================================================================
library(dplyr)
library(zoo)
library(moments)

print("Starter beregning af 30-dages rullende skewness for S&P 500...")

# 1. Definer stien (Opdateret til din Cleaned_CSV mappe)
sti_load <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/"

# 2. Indlæs den rensede S&P 500-fil
sp500_df <- read.csv(paste0(sti_load, "Cleaned_SP500.csv"), stringsAsFactors = FALSE)
sp500_df$Date <- as.Date(sp500_df$Date)

# Sørg for at dataen er sorteret kronologisk
sp500_df <- sp500_df %>% arrange(Date)

# 3. Beregn Rullende Skewness (30 dage)
# Vi bruger rollapply med align="right" for at sikre, at vi KUN bruger historiske data
sp500_skew <- sp500_df %>%
  mutate(
    Cleaned_SP500_SKEW = rollapply(Cleaned_SP500, width = 30, FUN = skewness, fill = NA, align = "right", na.rm = TRUE)
  ) %>%
  filter(!is.na(Cleaned_SP500_SKEW)) %>% # Fjern de første 29 dage uden et fuldt vindue
  select(Date, Cleaned_SP500_SKEW)

# 4. Gem resultatet
write.csv(sp500_skew, paste0(sti_load, "Cleaned_SP500_SKEW.csv"), row.names = FALSE)

print(paste("✅ SUCCESS! 'Cleaned_SP500_SKEW.csv' er gemt i Cleaned_CSV med", nrow(sp500_skew), "observationer."))
