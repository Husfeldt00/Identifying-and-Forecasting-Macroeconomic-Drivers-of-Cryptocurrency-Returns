# =========================================================================
# SCRIPT 32: RENSNING AF CHINA ECONOMIC POLICY UNCERTAINTY (CEPU)
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af China EPU...")

# 1. Definer stien
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/CEPU_Chinese_unc_index.csv"

# 2. Indlæs data
cepu_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og værdier
cepu_clean <- cepu_raw %>%
  mutate(
    Date = as.Date(observation_date),
    # Sikrer at værdien er numerisk
    Cleaned_CEPU = as.numeric(CHNMAINLANDEPU)
  ) %>%
  select(Date, Cleaned_CEPU) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Cleaned_CEPU))

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
cepu_final <- cepu_clean %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_CEPU = log(Cleaned_CEPU / lag(Cleaned_CEPU))
  ) %>%
  select(Date, Cleaned_CEPU) %>%
  na.omit() # Fjerner første observation (NA pga. lag)

# 5. Gem i din Cleaned_CSV mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_CEPU.csv"
write.csv(cepu_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset CEPU-data:\n")
print(head(cepu_final))
cat("\n✅ SUCCESS: CEPU er renset (log-afkast) og gemt i Cleaned_CSV mappen.\n")