# =========================================================================
# SCRIPT 24: RENSNING AF GPR, GPRT OG GPRA (3 SEPARATE FILER)
# =========================================================================
library(readxl)
library(dplyr)
library(zoo)
library(lubridate)

print("Starter rensning af Geopolitical Risk Indices (GPR, GPRT, GPRA)...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/gpr_export.xls"

# 2. Indlæs data
gpr_raw <- read_excel(fil_sti)

# 3. Formater datoer i basen
gpr_base <- gpr_raw %>%
  mutate(
    Date = as.Date(parse_date_time(month, orders = c("dmy", "mdy", "ymd")))
  ) %>%
  filter(!is.na(Date)) %>%
  arrange(Date)

# Skab en fuld 7-dages DAGLIG kalender der dækker hele perioden
alle_dage <- data.frame(Date = seq(min(gpr_base$Date), max(gpr_base$Date), by = "days"))

# =========================================================================
# DEL A: Hovedindekset (GPR)
# =========================================================================
gpr_final <- alle_dage %>%
  left_join(gpr_base %>% select(Date, Close = GPR) %>% mutate(Close = as.numeric(Close)), by = "Date") %>%
  mutate(Close_Interp = na.approx(Close, rule = 2)) %>%
  na.omit() %>%
  mutate(
    Log_Return = log(Close_Interp) - log(lag(Close_Interp)),
    Roll_2d = rollmean(Log_Return, k = 2, fill = NA, align = "right")
  ) %>%
  filter(!is.na(Roll_2d)) %>%
  mutate(gpr_standardized = as.numeric(scale(Roll_2d))) %>%
  select(Date, gpr_standardized)

# =========================================================================
# DEL B: Trusler (GPRT - Threats)
# =========================================================================
gprt_final <- alle_dage %>%
  left_join(gpr_base %>% select(Date, Close = GPRT) %>% mutate(Close = as.numeric(Close)), by = "Date") %>%
  mutate(Close_Interp = na.approx(Close, rule = 2)) %>%
  na.omit() %>%
  mutate(
    Log_Return = log(Close_Interp) - log(lag(Close_Interp)),
    Roll_2d = rollmean(Log_Return, k = 2, fill = NA, align = "right")
  ) %>%
  filter(!is.na(Roll_2d)) %>%
  mutate(gprt_standardized = as.numeric(scale(Roll_2d))) %>%
  select(Date, gprt_standardized)

# =========================================================================
# DEL C: Handlinger (GPRA - Acts)
# =========================================================================
gpra_final <- alle_dage %>%
  left_join(gpr_base %>% select(Date, Close = GPRA) %>% mutate(Close = as.numeric(Close)), by = "Date") %>%
  mutate(Close_Interp = na.approx(Close, rule = 2)) %>%
  na.omit() %>%
  mutate(
    Log_Return = log(Close_Interp) - log(lag(Close_Interp)),
    Roll_2d = rollmean(Log_Return, k = 2, fill = NA, align = "right")
  ) %>%
  filter(!is.na(Roll_2d)) %>%
  mutate(gpra_standardized = as.numeric(scale(Roll_2d))) %>%
  select(Date, gpra_standardized)

# =========================================================================
# GEM ALLE TRE FILER
# =========================================================================
gem_sti_gpr <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_GPR.csv"
gem_sti_gprt <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_GPRT.csv"
gem_sti_gpra <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_GPRA.csv"

write.csv(gpr_final, gem_sti_gpr, row.names = FALSE)
write.csv(gprt_final, gem_sti_gprt, row.names = FALSE)
write.csv(gpra_final, gem_sti_gpra, row.names = FALSE)

cat("\n✅ SUCCESS: Excel-filen er delt op, interpoleret til daglig og gemt som tre separate filer:\n")
cat("1. Cleaned_GPR.csv\n2. Cleaned_GPRT.csv\n3. Cleaned_GPRA.csv\n")
