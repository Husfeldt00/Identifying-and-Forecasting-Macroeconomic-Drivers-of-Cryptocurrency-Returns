# =========================================================================
# SCRIPT 31: BEREGN RULLENDE SKEWNESS FOR OLIE (UDEN GLOBAL SKALERING)
# =========================================================================
library(dplyr)
library(zoo)
library(moments)

print("Starter beregning af 30-dages rullende skewness for Olie (OIL)...")

# 1. Definer stien (Opdateret til din nye Cleaned_CSV mappe)
sti_load <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/"

# 2. Indlæs den rensede Olie-fil
oil_df <- read.csv(paste0(sti_load, "Cleaned_OIL.csv"), stringsAsFactors = FALSE)
oil_df$Date <- as.Date(oil_df$Date)

# Vi tvinger igen kolonne 2 til et standardnavn for at undgå 'object not found' fejl
colnames(oil_df)[2] <- "Cleaned_OIL"

# Sørg for at dataen er sorteret kronologisk, og der ikke er NA'er
oil_df <- oil_df %>% 
  arrange(Date) %>%
  filter(!is.na(Cleaned_OIL))

# 3. Beregn Rullende Skewness (30 dage)
oil_skew <- oil_df %>%
  mutate(
    # Vi ruller 30 dage bagud præcis ligesom med SP500 (align="right" forhindrer look-ahead bias)
    Cleaned_OIL_SKEW = rollapply(Cleaned_OIL, width = 30, FUN = skewness, fill = NA, align = "right", na.rm = TRUE)
  ) %>%
  select(Date, Cleaned_OIL_SKEW) %>%
  filter(!is.na(Cleaned_OIL_SKEW)) # Fjern de første 29 dage uden en fuld måned

# 4. Gem den nye fil direkte i Cleaned_CSV mappen
write.csv(oil_skew, paste0(sti_load, "Cleaned_OIL_SKEW.csv"), row.names = FALSE)

print(paste("✅ SUCCESS! 'Cleaned_OIL_SKEW.csv' er bygget og gemt med", nrow(oil_skew), "observationer."))
