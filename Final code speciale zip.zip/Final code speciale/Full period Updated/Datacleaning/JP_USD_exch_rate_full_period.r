# =========================================================================
# SCRIPT 9: RENSNING AF JPY/USD - KUN LOG-AFKAST
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af JPY/USD...")

# 1. Definer stien til din RAW fil (Opdateret sti)
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/JPY_USD Historical Data.csv"

# 2. Indlæs data
jpy_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og rens tal
jpy_clean <- jpy_raw %>%
  mutate(
    # Fanger formatet "MM/DD/YYYY" (eller lignende)
    Date = as.Date(parse_date_time(Date, orders = c("mdy", "dmy", "ymd"))),
    # Fanger prisen og fjerner evt. kommaer for at undgå NA
    Close = as.numeric(gsub(",", "", Price))
  ) %>%
  select(Date, Close) %>%
  # VIGTIGT: Sorterer kronologisk, da valuta-rådata ofte kommer nyeste-først
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
jpy_final <- jpy_clean %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_JPY = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_JPY) %>%
  na.omit() # Fjerner den første observation (NA pga. lag)

# 5. Gem resultatet i din Cleaned_CSV mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_JPY.csv"
write.csv(jpy_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset JPY/USD-data:\n")
print(head(jpy_final))
cat("\n✅ SUCCESS: JPY/USD er renset (kun log-afkast) og gemt i Cleaned_CSV mappen.\n")