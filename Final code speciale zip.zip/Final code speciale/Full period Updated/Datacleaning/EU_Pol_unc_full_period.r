# =========================================================================
# SCRIPT 16: RENSNING AF EUROPE POLICY UNCERTAINTY (KUN LOG-AFKAST)
# =========================================================================
library(readxl)
library(dplyr)
library(lubridate)

print("Starter rensning af Europe Policy Uncertainty (EPU)...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/Europe_Policy_Uncertainty_Data.xlsx"

# 2. Indlæs data
epu_raw <- read_excel(fil_sti)

# 3. Formater datoer og værdier
epu_clean <- epu_raw %>%
  mutate(
    # 1. Tvinger dem til at være tal (tekst som "Source:" bliver til NA her, hvilket giver samme advarsel, men det er meningen!)
    Year_num = suppressWarnings(as.numeric(Year)),
    Month_num = suppressWarnings(as.numeric(Month))
  ) %>%
  # 2. Filtrer alle de ødelagte tekst-rækker fra bunden af Excel-arket VÆK
  filter(!is.na(Year_num), !is.na(Month_num)) %>%
  mutate(
    # 3. Nu kan vi bygge datoen helt uden advarsler, fordi vi kun har rene tal tilbage
    Date = make_date(year = Year_num, month = Month_num, day = 1),
    
    # Fanger prisen og gør den numerisk
    Close = suppressWarnings(as.numeric(European_News_Index))
  ) %>%
  select(Date, Close) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
epu_final <- epu_clean %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_EPU = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_EPU) %>%
  na.omit() # Fjerner den første observation (NA pga. lag)

# 5. Gem resultatet i din Cleaned_CSV mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_EPU.csv"
write.csv(epu_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset EPU-data:\n")
print(head(epu_final))
cat("\n✅ SUCCESS: EPU er bygget fra Excel, renset (kun log-afkast) og gemt i Cleaned_CSV mappen.\n")
