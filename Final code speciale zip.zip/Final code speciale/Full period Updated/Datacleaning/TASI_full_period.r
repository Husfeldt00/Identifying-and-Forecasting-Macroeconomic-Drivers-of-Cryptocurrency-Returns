# =========================================================================
# SCRIPT 19: RENSNING AF TADAWUL ALL SHARE - KUN LOG-AFKAST
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af Tadawul All Share...")

# 1. Definer stien til din RAW fil (Opdateret sti)
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/Tadawul All Share Historical Data.csv"

# 2. Indlæs data
tadawul_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og rens priser
tadawul_clean <- tadawul_raw %>%
  mutate(
    Date = as.Date(parse_date_time(Date, orders = c("mdy", "dmy", "ymd"))),
    Close = as.numeric(gsub(",", "", Price))
  ) %>%
  filter(Vol. != "") %>% # Bruger dit volumen-filter
  select(Date, Close) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# Sikkerhedsventil: Hvis Vol-filteret fjernede alt
if(nrow(tadawul_clean) == 0) {
  print("⚠️ Advarsel: Ingen data tilbage! Fjerner volumen-filteret...")
  tadawul_clean <- tadawul_raw %>%
    mutate(
      Date = as.Date(parse_date_time(Date, orders = c("mdy", "dmy", "ymd"))),
      Close = as.numeric(gsub(",", "", Price))
    ) %>%
    select(Date, Close) %>%
    arrange(Date) %>%
    filter(!is.na(Date), !is.na(Close))
}

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
tadawul_final <- tadawul_clean %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_TADAWUL = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_TADAWUL) %>%
  na.omit() # Fjerner den første observation (NA pga. lag)

# 5. Gem resultatet i din Cleaned_CSV mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_TADAWUL.csv"
write.csv(tadawul_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset Tadawul-data:\n")
print(head(tadawul_final))
cat("\n✅ SUCCESS: Tadawul All Share er renset (kun log-afkast) og gemt i Cleaned_CSV mappen.\n")