# =========================================================================
# SCRIPT 20: RENSNING AF US LONG TREASURY YIELD - KUN SIMPLE DIFFERENCER
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af US Long Treasury...")

# 1. Definer stien til din RAW fil (Opdateret med "Updated")
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/US_long_treas.csv"

# 2. Indlæs data (FRED data, komma-separeret)
treas_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og værdier
treas_clean <- treas_raw %>%
  mutate(
    Date = as.Date(observation_date),
    # FRED data bruger ofte "." for manglende dage. suppressWarnings fjerner støj fra as.numeric()
    Close = suppressWarnings(as.numeric(DLTIIT))
  ) %>%
  select(Date, Close) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# 4. Matematik jf. Panagiotidis (2018) - SÆRLIGE REGLER FOR RENTER
treas_final <- treas_clean %>%
  mutate(
    # SIMPLE differencer (IKKE log-afkast!), fordi det er obligationsafkast/renter
    Cleaned_TREAS = Close - lag(Close)
  ) %>%
  select(Date, Cleaned_TREAS) %>%
  na.omit() # Fjerner den første observation (NA pga. lag)

# 5. Gem resultatet i din Cleaned_CSV mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_TREAS.csv"
write.csv(treas_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset Treasury-data:\n")
print(head(treas_final))
cat("\n✅ SUCCESS: US Long Treasury er renset (kun simple differencer) og gemt i Cleaned_CSV mappen.\n")