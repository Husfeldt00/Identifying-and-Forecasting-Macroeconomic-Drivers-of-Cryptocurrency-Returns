# =========================================================================
# SCRIPT 5: RENSNING AF ECB RENTEN (ECBDFR) - KUN SIMPLE DIFFERENCER
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af ECB-renten...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/ECBDFR.csv"

# 2. Indlæs data (Amerikansk format, komma-separeret fra FRED)
ecb_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og værdier
ecb_clean <- ecb_raw %>%
  mutate(
    Date = as.Date(observation_date),
    # Sikrer at den læses som et tal (suppressWarnings fjerner advarsler om manglende data som ".")
    Rate = suppressWarnings(as.numeric(ECBDFR))
  ) %>%
  select(Date, Rate) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Rate))

# 4. Matematik jf. Panagiotidis (2018) - SÆRLIGE REGLER FOR RENTER
ecb_final <- ecb_clean %>%
  mutate(
    # SIMPLE differencer (IKKE log-afkast), fordi det er en rente!
    Cleaned_ECB = Rate - lag(Rate)
  ) %>%
  select(Date, Cleaned_ECB) %>%
  na.omit() # Fjerner den første observation (NA pga. lag)

# 5. Gem resultatet i din Cleaned_CSV mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_ECB.csv"
write.csv(ecb_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset ECB-data:\n")
print(head(ecb_final))
cat("\n✅ SUCCESS: ECB renten er renset (kun simple differencer) og gemt i Cleaned_CSV mappen.\n")
