# =========================================================================
# SCRIPT 13: RENSNING AF SHANGHAI COMPOSITE (KUN LOG-AFKAST)
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af Shanghai Composite (SSEC)...")

# 1. Definer stien til din RAW fil (Opdateret)
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/Shanghai Composite Historical Data.csv"

# 2. Indlæs data
ssec_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og rens priser
ssec_clean <- ssec_raw %>%
  mutate(
    Date = as.Date(parse_date_time(Date, orders = c("mdy", "dmy", "ymd"))),
    Close = as.numeric(gsub(",", "", Price))
  ) %>%
  filter(Vol. != "") %>% # Bruger dit smarte volumen-filter
  select(Date, Close) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# Sikkerhedsventil
if(nrow(ssec_clean) == 0) {
  print("⚠️ Advarsel: Ingen data tilbage! Fjerner volumen-filteret...")
  ssec_clean <- ssec_raw %>%
    mutate(
      Date = as.Date(parse_date_time(Date, orders = c("mdy", "dmy", "ymd"))),
      Close = as.numeric(gsub(",", "", Price))
    ) %>%
    select(Date, Close) %>%
    arrange(Date) %>%
    filter(!is.na(Date), !is.na(Close))
}

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
ssec_final <- ssec_clean %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_SSEC = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_SSEC) %>%
  na.omit()

# 5. Gem resultatet i din Cleaned_CSV mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_SSEC.csv"
write.csv(ssec_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset SSEC-data:\n")
print(head(ssec_final))
cat("\n✅ SUCCESS: Shanghai Composite er renset (kun log-afkast) og gemt i Cleaned_CSV mappen.\n")