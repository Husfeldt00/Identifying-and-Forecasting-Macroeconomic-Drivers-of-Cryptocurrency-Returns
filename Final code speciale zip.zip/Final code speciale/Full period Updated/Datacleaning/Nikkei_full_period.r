# =========================================================================
# SCRIPT 12: RENSNING AF NIKKEI 225 - KUN LOG-AFKAST
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af Nikkei 225...")

# 1. Definer stien til din RAW fil (Opdateret med "Updated")
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/Nikkei 225 Historical Data.csv"

# 2. Indlæs data
nikkei_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og rens priser
nikkei_clean <- nikkei_raw %>%
  mutate(
    # Fanger formatet "MM/DD/YYYY"
    Date = as.Date(parse_date_time(Date, orders = c("mdy", "dmy", "ymd"))),
    # Fjerner tusindtalskommaer og konverterer til tal
    Close = as.numeric(gsub(",", "", Price))
  ) %>%
  # Vi fjerner dage uden volumen, så vi kan luge ud i de falske lukkedage
  filter(Vol. != "") %>%
  select(Date, Close) %>%
  # Sorterer kronologisk
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# Sikkerhedsventil: Hvis filteret fjernede alt (pga. manglende volumen-data i råfilen)
if(nrow(nikkei_clean) == 0) {
  print("⚠️ Advarsel: Ingen data tilbage! Fjerner volumen-filteret...")
  nikkei_clean <- nikkei_raw %>%
    mutate(
      Date = as.Date(parse_date_time(Date, orders = c("mdy", "dmy", "ymd"))),
      Close = as.numeric(gsub(",", "", Price))
    ) %>%
    select(Date, Close) %>%
    arrange(Date) %>%
    filter(!is.na(Date), !is.na(Close))
}

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
nikkei_final <- nikkei_clean %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_NIKKEI = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_NIKKEI) %>%
  na.omit() # Fjerner den første observation (NA pga. lag)

# 5. Gem resultatet direkte i din Cleaned_CSV mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_NIKKEI.csv"
write.csv(nikkei_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset Nikkei-data:\n")
print(head(nikkei_final))
cat("\n✅ SUCCESS: Nikkei 225 er renset (kun log-afkast) og gemt i Cleaned_CSV mappen.\n")