# =========================================================================
# SCRIPT 2: RENSNING AF RÅOLIE (FIX AF NEGATIVE PRISER - KUN LOG-AFKAST)
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af Råolie...")

# 1. Definer stien til din RAW fil (Opdateret med 'Updated')
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/crude-oil-price.csv"

# 2. Indlæs data
oil_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer, rens priser og håndter negative værdier
oil_clean <- oil_raw %>%
  mutate(
    Date = as.Date(observation_date),
    Close = suppressWarnings(as.numeric(DCOILWTICO))
  ) %>%
  select(Date, Close) %>%
  arrange(Date) %>%
  # Vi fjerner normale NAs
  filter(!is.na(Date), !is.na(Close)) %>%
  # GENIALT: Fjerner de negative priser (og nul) fra april 2020, så log() ikke crasher!
  # Master Scriptet vil automatisk lappe dette hul senere.
  filter(Close > 0)

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
oil_final <- oil_clean %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_OIL = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_OIL) %>%
  na.omit() # Fjerner den første observation (NA pga. lag)

# 5. Gem resultatet direkte i din Cleaned_CSV mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_OIL.csv"
write.csv(oil_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset Olie-data:\n")
print(head(oil_final))
cat("\n✅ SUCCESS: Råolie er renset (negative priser fjernet, kun log-afkast) og gemt i Cleaned_CSV mappen.\n")