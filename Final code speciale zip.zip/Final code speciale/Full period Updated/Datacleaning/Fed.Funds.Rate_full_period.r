# =========================================================================
# SCRIPT 4: RENSNING AF FED FUNDS RATE (SÆRLIGE REGLER)
# =========================================================================
library(dplyr)
library(zoo)
library(lubridate)

print("Starter rensning af FED-renten...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/Fed_fund_effective_rate.csv"

# 2. Indlæs data (Amerikansk format, komma-separeret)
fed_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og værdier
fed_clean <- fed_raw %>%
  mutate(
    Date = as.Date(observation_date),
    # Fanger værdien og gør den numerisk (håndterer evt. manglende punktummer)
    Rate = suppressWarnings(as.numeric(DFF))
  ) %>%
  select(Date, Rate) %>%
  arrange(Date) %>%
  filter(!is.na(Date))

# 4. Skab en fuld 7-dages kalender (for en sikkerheds skyld)
alle_dage <- data.frame(Date = seq(min(fed_clean$Date), max(fed_clean$Date), by = "days"))

fed_interp <- alle_dage %>%
  left_join(fed_clean, by = "Date") %>%
  mutate(
    # Fyld huller ud med sidste kendte rente (na.locf = Last Observation Carried Forward)
    # Dette er bedre til renter end lineær interpolation, da renter ændres i "trin"
    Rate_Interp = na.locf(Rate, na.rm = FALSE)
  ) %>%
  na.omit()

# 5. Matematik jf. Panagiotidis (2018) - BEMÆRK UNDTAGELSERNE!
fed_final <- fed_interp %>%
  mutate(
    # SIMPLE differencer (IKKE log-afkast!)
    Diff_Return = Rate_Interp - lag(Rate_Interp)
    
    # INGEN 2-dages glidende gennemsnit her!
  ) %>%
  filter(!is.na(Diff_Return)) %>%
  mutate(
    # Standardisering (Mean = 0, Varians = 1)
    fed_standardized = as.numeric(scale(Diff_Return))
  ) %>%
  select(Date, fed_standardized)

# 6. Gem resultatet
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_FED.csv"
write.csv(fed_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset FED-data:\n")
print(head(fed_final))
cat("\n✅ SUCCESS: FED Funds Rate er renset (med simple differencer) og gemt som 'Cleaned_FED.csv'.\n")