# =========================================================================
# SCRIPT 14: RENSNING AF CBOE DJIA VOLATILITY INDEX (VXD)
# =========================================================================
library(dplyr)
library(zoo)
library(lubridate)

print("Starter rensning af DJIA Volatility Index (VXD)...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/Cboe DJIA Volatility Index.csv"

# 2. Indlæs data
vxd_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og find prisen
vxd_clean <- vxd_raw %>%
  mutate(
    # Fanger formatet "MM/DD/YYYY" (fx 09/18/2009)
    Date = as.Date(parse_date_time(DATE, orders = c("mdy", "dmy", "ymd"))),
    # Sikrer os, at det er numerisk
    Close = as.numeric(CLOSE)
  ) %>%
  select(Date, Close) %>%
  # Sorterer kronologisk for en sikkerheds skyld
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# 4. Skab en fuld 7-dages kalender og flet dataen
alle_dage <- data.frame(Date = seq(min(vxd_clean$Date), max(vxd_clean$Date), by = "days"))

vxd_interp <- alle_dage %>%
  left_join(vxd_clean, by = "Date") %>%
  mutate(
    # Ægte lineær interpolation over weekender og helligdage
    Close_Interp = na.approx(Close, na.rm = FALSE)
  ) %>%
  na.omit()

# 5. Matematik jf. Panagiotidis (2018)
vxd_final <- vxd_interp %>%
  mutate(
    # Logaritmiske afkast
    Log_Return = log(Close_Interp) - log(lag(Close_Interp)),
    
    # 2 dags gennemsnit
    VXD_2d = rollmean(Log_Return, k = 2, fill = NA, align = "right")
  ) %>%
  filter(!is.na(VXD_2d)) %>%
  mutate(
    # Standardisering 
    vxd_standardized = as.numeric(scale(VXD_2d))
  ) %>%
  select(Date, vxd_standardized)

# 6. Gem resultatet
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Cleaned_VXD.csv"
write.csv(vxd_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset og interpoleret VXD-data:\n")
print(head(vxd_final))
cat("\n✅ SUCCESS: VXD volatilitet er renset, interpoleret og gemt som 'Cleaned_VXD.csv'.\n")
