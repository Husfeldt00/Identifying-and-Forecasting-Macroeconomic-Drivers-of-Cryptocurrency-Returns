# =========================================================================
# SCRIPT 15: RENSNING AF US POLICY UNCERTAINTY (KUN RÅ DATA)
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af US Policy Uncertainty (USEPU)...")

# 1. Definer stien til din RAW fil (Opdateret med "Updated")
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/US_Eco_Poli_Unc.csv"

# 2. Indlæs data
usepu_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og værdier
# Vi beholder datoen som "1. i måneden" (da det er månedlig data), 
# Master Scriptet vil senere udvide dette til daglig data.
usepu_clean <- usepu_raw %>%
  mutate(
    Date = as.Date(observation_date),
    Cleaned_USEPU = as.numeric(USEPUINDXM)
  ) %>%
  select(Date, Cleaned_USEPU) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Cleaned_USEPU))

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
# Da vi arbejder med et indeks, bruger vi log-afkast præcis som med aktier
usepu_final <- usepu_clean %>%
  mutate(
    Cleaned_USEPU = log(Cleaned_USEPU / lag(Cleaned_USEPU))
  ) %>%
  select(Date, Cleaned_USEPU) %>%
  na.omit()

# 5. Gem resultatet direkte i din Cleaned_CSV mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_USEPU.csv"
write.csv(usepu_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset USEPU-data:\n")
print(head(usepu_final))
cat("\n✅ SUCCESS: USEPU er renset (log-afkast) og gemt i Cleaned_CSV mappen.\n")