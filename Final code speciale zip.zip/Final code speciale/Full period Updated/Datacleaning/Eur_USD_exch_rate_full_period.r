# =========================================================================
# SCRIPT 6: RENSNING AF EUR/USD - KUN LOG-AFKAST
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af EUR/USD...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/EUR_USD Historical Data.csv"

# 2. Indlæs data
eur_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og forbered data
eur_clean <- eur_raw %>%
  mutate(
    # Fanger formatet "MM/DD/YYYY"
    Date = as.Date(parse_date_time(Date, orders = c("mdy", "dmy", "ymd"))),
    # Fanger prisen. Fjerner evt. kommaer fra store tal for en sikkerheds skyld
    Close = as.numeric(gsub(",", "", Price))
  ) %>%
  select(Date, Close) %>%
  # VIGTIGT: Sorterer kronologisk, da rådataen ofte er baglæns
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
eur_final <- eur_clean %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_EUR = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_EUR) %>%
  na.omit() # Fjerner den første observation (NA pga. lag)

# 5. Gem resultatet i din nye Litecoin 'Cleaned_CSV' mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Cleaned_CSV/Cleaned_EUR.csv"
write.csv(eur_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset EUR/USD-data:\n")
print(head(eur_final))
cat("\n✅ SUCCESS: EUR/USD er renset (kun log-afkast) og gemt i den nye mappe.\n")
