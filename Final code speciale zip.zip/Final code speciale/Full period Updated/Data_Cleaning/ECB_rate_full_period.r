# =========================================================================
# SCRIPT 5: RENSNING AF ECB RENTEN (KUN SIMPLE DIFFERENCER)
# =========================================================================
library(dplyr)
library(zoo)

print("Starter rensning af ECB-renten...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/ECBDFR.csv"

# 2. Indlæs data
ecb_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og værdier
ecb_clean <- ecb_raw %>%
  mutate(
    Date = as.Date(observation_date),
    # Sikrer at den læses som et tal
    Rate = suppressWarnings(as.numeric(ECBDFR))
  ) %>%
  select(Date, Rate) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Rate))

# 4. Skab en fuld 7-dages kalender (VIGTIGT FOR RENTER)
alle_dage <- data.frame(Date = seq(min(ecb_clean$Date), max(ecb_clean$Date), by = "days"))

ecb_interp <- alle_dage %>%
  left_join(ecb_clean, by = "Date") %>%
  mutate(
    # Fyld huller ud med sidste kendte rente (Fredagens rente gælder lørdag/søndag)
    Rate_Interp = na.locf(Rate, na.rm = FALSE)
  ) %>%
  na.omit()

# 5. Matematik jf. Panagiotidis (2018) - INGEN LOG OG INGEN 2-DAY AVERAGE
ecb_final <- ecb_interp %>%
  mutate(
    # SIMPLE differencer (IKKE log-afkast)
    Cleaned_ECB = Rate_Interp - lag(Rate_Interp)
  ) %>%
  select(Date, Cleaned_ECB) %>%
  na.omit() # Fjerner den første observation

# 6. Gem resultatet i din nye Litecoin 'Cleaned_CSV' mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/Cleaned_ECB.csv"
write.csv(ecb_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset ECB-data:\n")
print(head(ecb_final))
cat("\n✅ SUCCESS: ECB er renset (simpel difference) og gemt i den nye mappe.\n")