# =========================================================================
# SCRIPT 17: RENSNING AF CHINESE POLICY UNCERTAINTY (CEPU) - KUN LOG-AFKAST
# =========================================================================
library(dplyr)
library(zoo)

print("Starter rensning af Chinese Policy Uncertainty (CEPU)...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/CEPU_Chinese_unc_index.csv"

# 2. Indlæs data
cepu_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og værdier
cepu_clean <- cepu_raw %>%
  mutate(
    # Fanger datoerne i formatet yyyy-mm-dd
    Date = as.Date(observation_date),
    # Fanger den kinesiske kolonne
    Close = as.numeric(CHNMAINLANDEPU)
  ) %>%
  select(Date, Close) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# 4. Skab en fuld 7-dages DAGLIG kalender og flet dataen
# Dette er KRITISK for månedligt data, for at log-afkastet bliver dagligt!
alle_dage <- data.frame(Date = seq(min(cepu_clean$Date), max(cepu_clean$Date), by = "days"))

cepu_interp <- alle_dage %>%
  left_join(cepu_clean, by = "Date") %>%
  mutate(
    # Lineær interpolation (udfylder de ca. 30 dage mellem hver månedlige observation)
    Close_Interp = na.approx(Close, rule = 2)
  ) %>%
  na.omit()

# 5. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE AF INTERPOLERET DATA
cepu_final <- cepu_interp %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_CEPU = log(Close_Interp / lag(Close_Interp))
  ) %>%
  select(Date, Cleaned_CEPU) %>%
  na.omit() # Fjerner den første dag (NA pga. lag)

# 6. Gem resultatet i din nye Litecoin 'Cleaned_CSV' mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/Cleaned_CEPU.csv"
write.csv(cepu_final, gem_sti, row.names = FALSE)

cat("\nFørste 10 rækker af renset CEPU-data (daglige afkast):\n")
print(head(cepu_final, 10))
cat("\n✅ SUCCESS: CEPU er interpoleret til daglig, log-transformeret og gemt i den nye mappe.\n")
