# =========================================================================
# SCRIPT 26: RENSNING AF CLIMATE POLICY UNCERTAINTY (KUN LOG-AFKAST)
# =========================================================================
library(readxl)
library(dplyr)
library(zoo)

print("Starter rensning af CPU. Frasorterer automatisk variabler med negative/nul værdier...")

# 1. Definer stier 
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/cpu_pu (2).xlsx"
# VIGTIGT: Opdateret til den nye Litecoin mappe!
basis_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/"

# 2. Indlæs data fra arket "data"
cpu_raw <- read_excel(fil_sti, sheet = "data")

# 3. Rens datoen én gang for alle
cpu_base <- cpu_raw %>%
  mutate(
    Date = as.Date(paste0(gsub("M|m", "-", date), "-01"))
  ) %>%
  filter(!is.na(Date)) %>%
  arrange(Date)

# 4. Byg den store, daglige master-kalender (Nødvendigt da data er månedligt)
alle_dage <- data.frame(Date = seq(min(cpu_base$Date), max(cpu_base$Date), by = "days"))

# Alle de kolonner fra Excel-arket vi potentielt vil bruge
kolonner_at_rense <- c("cpu_index_narrow", "cpu_index_broad", "cpu_index_gavriilidis", 
                       "cpnews_index_narrow", "cpnews_index_broad", "cpsent_index", 
                       "cpu_instrument", "cpu_shock")

# 5. KØR LOOPET: Tjek, interpoler, tag log-afkast og gem!
for (kolonne_navn in kolonner_at_rense) {
  
  if (kolonne_navn %in% names(cpu_base)) {
    
    # Træk Date og den specifikke kolonne ud
    temp_data <- cpu_base %>%
      select(Date, Close = all_of(kolonne_navn)) %>%
      mutate(Close = as.numeric(Close)) %>%
      filter(!is.na(Close))
    
    # =====================================================================
    # TJEK FOR NEGATIVE ELLER NUL-VÆRDIER
    # =====================================================================
    if (any(temp_data$Close <= 0, na.rm = TRUE)) {
      print(paste("⏭️ Skipper:", kolonne_navn, "- Indeholder nul eller negative værdier!"))
      next # Springer direkte videre til næste kolonne
    }
    
    # b. Daglig interpolation for de kolonner, der overlevede tjekket
    temp_interp <- alle_dage %>%
      left_join(temp_data, by = "Date") %>%
      mutate(Close_Interp = na.approx(Close, rule = 2)) %>%
      na.omit()
    
    # c. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE AF INTERPOLERET DATA
    temp_final <- temp_interp %>%
      mutate(
        Cleaned_Var = log(Close_Interp / lag(Close_Interp))
      ) %>%
      select(Date, Cleaned_Var) %>%
      na.omit() # Fjerner den første dag (NA pga. lag)
    
    # Omdøb kolonnen til filnavnet (f.eks. Cleaned_cpu_index_narrow)
    navn_til_kolonne <- paste0("Cleaned_", kolonne_navn)
    colnames(temp_final)[2] <- navn_til_kolonne
    
    # d. Gem filen direkte i din Litecoin 'Cleaned_CSV' mappe
    gem_filnavn <- paste0(basis_sti, navn_til_kolonne, ".csv")
    write.csv(temp_final, gem_filnavn, row.names = FALSE)
    
    print(paste("✅ Succes! Renset og gemt som:", paste0(navn_til_kolonne, ".csv")))
    
  } else {
    print(paste("⚠️ Fandt ikke kolonnen:", kolonne_navn))
  }
}

print("Færdig! Alle overlevende CPU-kolonner er gemt med rene log-afkast i den nye mappe.")
