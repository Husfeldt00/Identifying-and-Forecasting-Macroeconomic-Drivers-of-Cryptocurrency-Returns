# =========================================================================
# SCRIPT 15: RENSNING AF US POLICY UNCERTAINTY (KUN LOG-AFKAST, DAGLIG INTERP.)
# =========================================================================
library(dplyr)
library(zoo)
library(lubridate)

print("Starter rensning af US Policy Uncertainty (USEPU)...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/US_Eco_Poli_Unc.csv"

# 2. Indlæs data
usepu_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og værdier
usepu_clean <- usepu_raw %>%
  mutate(
    # Fanger datoerne i formatet yyyy-mm-dd
    Date = as.Date(observation_date),
    Close = as.numeric(USEPUINDXM)
  ) %>%
  select(Date, Close) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# 4. Skab en fuld 7-dages DAGLIG kalender og flet dataen
alle_dage <- data.frame(Date = seq(min(usepu_clean$Date), max(usepu_clean$Date), by = "days"))

usepu_interp <- alle_dage %>%
  left_join(usepu_clean, by = "Date") %>%
  mutate(
    # Lineær interpolation (udfylder de ca. 30 dage mellem hver månedlige observation)
    Close_Interp = na.approx(Close, rule = 2)
  ) %>%
  # RETTELSEN: Vi beholder KUN Date og den interpolerede kolonne, FØR vi sletter NAs
  select(Date, Close_Interp) %>%
  na.omit()

# 5. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE AF INTERPOLERET DATA
usepu_final <- usepu_interp %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_USEPU = log(Close_Interp / lag(Close_Interp))
  ) %>%
  select(Date, Cleaned_USEPU) %>%
  na.omit() # Fjerner den første observation (NA pga. lag)

# 6. Gem resultatet i din nye Litecoin 'Cleaned_CSV' mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/Cleaned_USEPU.csv"
write.csv(usepu_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset og interpoleret USEPU-data:\n")
print(head(usepu_final, 5))
cat("\n✅ SUCCESS: USEPU er interpoleret til daglig, renset (kun log-afkast) og gemt i den nye mappe.\n")
