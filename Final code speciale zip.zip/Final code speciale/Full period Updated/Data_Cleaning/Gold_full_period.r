# =========================================================================
# SCRIPT 3: RENSNING AF GULD (GOLD NY FUTURES) - KUN LOG-AFKAST
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af Guld (NY Futures)...")

# 1. Definer stien til din RAW fil (Husk at tjekke stien)
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code speciale/Full period Updated/Raw_data_full_period/Gold Futures Historical Data_NY.csv"

# 2. Indlæs data (Vi bruger read.csv til amerikanske filer)
gold_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og rens tal
gold_clean <- gold_raw %>%
  mutate(
    # Fanger datoformatet dmy (dag-måned-år), mdy eller ymd
    Date = as.Date(parse_date_time(Date, orders = c("dmy", "mdy", "ymd"))),
    
    # 1. Fjern de amerikanske kommaer fra teksten (fx "1,950.00" -> "1950.00")
    Price_clean = gsub(",", "", Price),
    
    # 2. Gør den numerisk og kald den 'Close'
    Close = as.numeric(Price_clean)
  ) %>%
  select(Date, Close) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
gold_final <- gold_clean %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference (regnet på Close)
    Cleaned_GOLD = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_GOLD) %>%
  na.omit() # Fjerner den første observation (NA pga. lag)

# 5. Gem resultatet
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code speciale/Full period Updated/Cleaned_CSV/Cleaned_GOLD_NY.csv"
write.csv(gold_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset Guld-data:\n")
print(head(gold_final))
cat("\n✅ SUCCESS: Guld er renset og gemt! Klar til Master Scriptet.\n")
