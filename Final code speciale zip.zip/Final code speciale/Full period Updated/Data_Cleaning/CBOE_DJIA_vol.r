# =========================================================================
# SCRIPT: RENSNING AF CBOE DJIA VOLATILITY INDEX (VXD)
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af DJIA Volatility Index (VXD)...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/Cboe DJIA Volatility Index.csv"

# 2. Indlæs data
vxd_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og find prisen
vxd_clean <- vxd_raw %>%
  mutate(
    # Fanger formatet "MM/DD/YYYY" (fx 09/18/2009)
    Date = as.Date(parse_date_time(DATE, orders = c("mdy", "dmy", "ymd"))),
    # Sikrer os, at det er numerisk
    Close = as.numeric(CLOSE)
  ) %>%
  select(Date, Close) %>%
  # Sorterer kronologisk for en sikkerheds skyld
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# 4. Matematik jf. Panagiotidis
vxd_final <- vxd_clean %>%
  mutate(
    log_ret = log(Close / lag(Close)),
    vxd_2d = (log_ret + lag(log_ret)) / 2
  ) %>%
  select(Date, vxd_2d) %>%
  na.omit()

# 5. Gem resultatet i din nye Litecoin 'Cleaned_CSV' mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/Cleaned_VXD.csv"
write.csv(vxd_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset VXD-data:\n")
print(head(vxd_final))
cat("\n✅ SUCCESS: VXD volatilitet er renset (kun log-afkast) og gemt i den nye mappe.\n")
