# =========================================================================
# SCRIPT 23: RENSNING AF MOEX RUSSIA (KUN LOG-AFKAST)
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af MOEX Russia Index...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/MOEX Russia Index Historical Data.csv"

# 2. Indlæs data
moex_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og rens priser
moex_clean <- moex_raw %>%
  mutate(
    # Fanger formatet (fx "03/16/2026")
    Date = as.Date(parse_date_time(Date, orders = c("mdy", "dmy", "ymd"))),
    # Fjerner tusindtalskommaer og konverterer til tal
    Close = as.numeric(gsub(",", "", Price))
  ) %>%
  # Vi fjerner evt. forudfyldte "falske" weekend-dage uden volumen
  filter(Vol. != "") %>%
  select(Date, Close) %>%
  # Sorterer kronologisk
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# Sikkerhedsventil: Hvis filteret fjernede alt (pga. manglende volumen-data i råfilen)
if(nrow(moex_clean) == 0) {
  print("⚠️ Advarsel: Ingen data tilbage! Fjerner volumen-filteret...")
  moex_clean <- moex_raw %>%
    mutate(
      Date = as.Date(parse_date_time(Date, orders = c("mdy", "dmy", "ymd"))),
      Close = as.numeric(gsub(",", "", Price))
    ) %>%
    select(Date, Close) %>%
    arrange(Date) %>%
    filter(!is.na(Date), !is.na(Close))
}

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
moex_final <- moex_clean %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_MOEX = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_MOEX) %>%
  na.omit() # Fjerner den første observation pga. lag

# 5. Gem resultatet i din nye Litecoin 'Cleaned_CSV' mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/Cleaned_MOEX.csv"
write.csv(moex_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset MOEX-data:\n")
print(head(moex_final))
cat("\n✅ SUCCESS: MOEX Russia er renset (kun log-afkast) og gemt i den nye mappe.\n")
