# =========================================================================
# SCRIPT 1: RENSNING AF BITCOIN (BTC) - KUN LOG-AFKAST
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af Bitcoin...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/BTC_full_period.csv"

# 2. Indlæs data
btc_raw <- read.csv2(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og rens
btc_clean <- btc_raw %>%
  rename(
    Date_Raw = DateTime,
    Price_Raw = Bitcoin.Price.Linear
  ) %>%
  mutate(
    # Fanger "14-04-2010 00:00" formatet og konverterer til ren dato
    Date = as.Date(dmy_hm(Date_Raw)),
    # Sørger for at prisen behandles som et tal
    Close = as.numeric(Price_Raw)
  ) %>%
  select(Date, Close) %>%
  arrange(Date) %>%
  na.omit()

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
btc_final <- btc_clean %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_BTC = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_BTC) %>%
  na.omit() # Fjerner den første dag (som bliver NA pga. lag)

# 5. Gem resultatet i din nye Litecoin 'Cleaned_CSV' mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/Cleaned_BTC.csv"
write.csv(btc_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset Bitcoin-data:\n")
print(head(btc_final))
cat("\n✅ SUCCESS: Bitcoin er renset (kun log-afkast) og gemt i den nye mappe.\n")
