# =========================================================================
# TRIN 1: THE LITECOIN MASTER SCRIPT (BYGGER NYE FILER EKSKL. BITCOIN)
# =========================================================================
library(dplyr)
library(purrr)
library(zoo)

print("Starter Litecoin Master Scriptet...")

basis_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/"

# Find alle CSV-filer i mappen
alle_filer <- list.files(path = basis_sti, pattern = "^Cleaned_.*\\.csv$", full.names = TRUE)

# 🚨 FJERNER BITCOIN FRA DATASÆTTET
alle_filer <- alle_filer[!grepl("Cleaned_BTC\\.csv", alle_filer, ignore.case = TRUE)]

# Indlæs og flet
master_raw <- alle_filer %>%
  map(read.csv) %>%
  reduce(full_join, by = "Date") %>%
  mutate(Date = as.Date(Date)) %>%
  arrange(Date)

# Skab den NYE kalender (Starter d. 1. maj 2013)
start_dato <- as.Date("2013-05-01")
slut_dato  <- as.Date("2024-12-31")
master_kalender <- data.frame(Date = seq(start_dato, slut_dato, by = "days"))

# Flet og Interpoler
renter <- c("Cleaned_FED", "Cleaned_ECB", "Cleaned_TREAS")

master_interp <- master_kalender %>%
  left_join(master_raw, by = "Date") %>%
  mutate(
    across(any_of(renter), ~ na.locf(.x, na.rm = FALSE)),
    across(-c(Date, any_of(renter)), ~ na.approx(.x, na.rm = FALSE, rule = 2))
  )

# 2-dages glidende gennemsnit
master_smoothed <- master_interp %>%
  mutate(
    across(
      -c(Date, any_of(renter)),
      ~ rollmean(.x, k = 2, fill = NA, align = "right")
    )
  ) %>%
  na.omit()

# Funktion til at klippe og standardisere
slice_and_scale <- function(df, start, slut, filnavn) {
  sliced_df <- df %>% filter(Date >= as.Date(start) & Date <= as.Date(slut))
  scaled_df <- sliced_df %>% mutate(across(-Date, ~ as.numeric(scale(.x))))
  gem_sti <- paste0(basis_sti, "MASTER_LITECOIN_", filnavn, ".csv")
  write.csv(scaled_df, gem_sti, row.names = FALSE)
  print(paste("✅ Oprettet", filnavn, "med", nrow(scaled_df), "observationer."))
}

# Kør funktionen på de 4 nye perioder
slice_and_scale(master_smoothed, "2013-05-01", "2024-12-31", "Full_Period")
slice_and_scale(master_smoothed, "2013-05-01", "2017-01-03", "P1")
slice_and_scale(master_smoothed, "2017-01-04", "2017-06-23", "P2")
slice_and_scale(master_smoothed, "2017-06-24", "2024-12-31", "P3")
