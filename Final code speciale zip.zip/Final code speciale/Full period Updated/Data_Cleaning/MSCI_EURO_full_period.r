# =========================================================================
# SCRIPT 22: RENSNING AF MSCI EUROPE (KUN LOG-AFKAST, BEHOLDT INTERPOLATION)
# =========================================================================
library(dplyr)
library(zoo)
library(lubridate)

print("Starter rensning og splejsning af MSCI Europe...")

# 1. Definer stier til dine TO RAW filer
fil_sti_monthly <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/MSCI_monthly_full_period.csv"
fil_sti_daily <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/MSCI Europe Historical Data.csv"

# 2. Indlæs begge filer
msci_monthly_raw <- read.csv(fil_sti_monthly, stringsAsFactors = FALSE)
msci_daily_raw <- read.csv(fil_sti_daily, stringsAsFactors = FALSE)

# 3. Rens den DAGLIGE data først
msci_daily <- msci_daily_raw %>%
  mutate(
    Date = as.Date(parse_date_time(Date, orders = c("mdy", "dmy", "ymd"))),
    Close = as.numeric(gsub(",", "", Price))
  ) %>%
  select(Date, Close) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# Find ud af hvornår den daglige data starter
start_paa_daglig <- min(msci_daily$Date)
print(paste("Den daglige data starter:", start_paa_daglig))

# 4. Rens den MÅNEDLIGE data (Format "MM/YYYY")
msci_monthly <- msci_monthly_raw %>%
  mutate(
    Date = as.Date(my(Date)),
    Close = as.numeric(MSCI.Europe)
  ) %>%
  select(Date, Close) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close)) %>%
  # VIGTIGT: Vi beholder kun den månedlige data, der ligger FØR den daglige data starter!
  filter(Date < start_paa_daglig)

# 5. Splejs de to datasæt sammen
msci_kombineret <- bind_rows(msci_monthly, msci_daily) %>%
  arrange(Date)

# 6. Skab en fuld 7-dages kalender og flet dataen
alle_dage <- data.frame(Date = seq(min(msci_kombineret$Date), max(msci_kombineret$Date), by = "days"))

msci_interp <- alle_dage %>%
  left_join(msci_kombineret, by = "Date") %>%
  mutate(
    # Lineær interpolation (klarer BÅDE de månedlige huller i starten og weekendhullerne til sidst)
    Close_Interp = na.approx(Close, na.rm = FALSE)
  ) %>%
  # RETTELSEN: Vi beholder kun Dato og Interpoleret Close, FØR vi sletter NAs
  select(Date, Close_Interp) %>%
  na.omit()

# 7. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE AF INTERPOLERET DATA
msci_final <- msci_interp %>%
  mutate(
    Cleaned_MSCI = log(Close_Interp / lag(Close_Interp))
  ) %>%
  select(Date, Cleaned_MSCI) %>%
  na.omit() # Fjerner den første observation (NA pga. lag)

# 8. Gem resultatet i din nye Litecoin 'Cleaned_CSV' mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/Cleaned_MSCI.csv"
write.csv(msci_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset MSCI Europe-data (tjek at det er dagligt!):\n")
print(head(msci_final))
cat("\n✅ SUCCESS: MSCI Europe er splejset, interpoleret, log-transformeret og gemt i den nye mappe.\n")
