# =========================================================================
# SCRIPT 30: BEREGN RULLENDE SKEWNESS FOR S&P 500 (UDEN STANDARDISERING)
# =========================================================================
library(dplyr)
library(zoo)
library(moments)

print("Starter beregning af 30-dages rullende skewness for S&P 500...")

# 1. Definer stien til din nye Litecoin mappe
basis_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/"

# 2. Indlæs den rensede SP500-fil (sørg for at du har kørt S&P 500 rensningsscriptet først!)
sp500_df <- read.csv(paste0(basis_sti, "Cleaned_SP500.csv"))
sp500_df$Date <- as.Date(sp500_df$Date)

# Sikrer os, at vi har fat i den rigtige kolonne (tvinger den til at hedde Cleaned_SP500)
colnames(sp500_df)[2] <- "Cleaned_SP500"

# Sørg for at dataen er sorteret kronologisk
sp500_df <- sp500_df %>% arrange(Date)

# 3. Beregn Rullende Skewness (30 dage)
sp500_skew <- sp500_df %>%
  mutate(
    # Vi ruller 30 dage bagud på de rene log-afkast
    Cleaned_SP500_SKEW = rollapply(Cleaned_SP500, width = 30, FUN = skewness, fill = NA, align = "right", na.rm = TRUE)
  ) %>%
  filter(!is.na(Cleaned_SP500_SKEW)) %>% # Fjern de første 29 dage uden en fuld måned
  select(Date, Cleaned_SP500_SKEW) # Behold kun Date og den rå Skewness

# 4. Gem den nye fil tilbage i samme mappe
write.csv(sp500_skew, paste0(basis_sti, "Cleaned_SP500_SKEW.csv"), row.names = FALSE)

print(paste("✅ SUCCESS! 'Cleaned_SP500_SKEW.csv' er bygget (kun rå skewness) og gemt med", nrow(sp500_skew), "observationer."))

