# =========================================================================
# SCRIPT 31: BEREGN 30-DAGES RULLENDE SKEWNESS FOR OLIE (UDEN STANDARDISERING)
# =========================================================================
library(dplyr)
library(zoo)
library(moments)

print("Starter beregning af 30-dages rullende skewness for Olie (OIL)...")

# 1. Definer stien til din nye Litecoin mappe
basis_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/"

# 2. Indlæs den rensede Olie-fil (som nu indeholder de rene log-afkast)
oil_df <- read.csv(paste0(basis_sti, "Cleaned_OIL.csv"))
oil_df$Date <- as.Date(oil_df$Date)

# Sikrer os, at vi har fat i den rigtige kolonne
colnames(oil_df)[2] <- "Cleaned_OIL"

# Sørg for at dataen er sorteret kronologisk
oil_df <- oil_df %>% arrange(Date)

# 3. Beregn Rullende Skewness (30 dage)
oil_skew <- oil_df %>%
  mutate(
    # Vi ruller 30 dage bagud (kræver minimum 30 dage før den spytter et tal ud)
    Cleaned_OIL_SKEW = rollapply(Cleaned_OIL, width = 30, FUN = skewness, fill = NA, align = "right", na.rm = TRUE)
  ) %>%
  filter(!is.na(Cleaned_OIL_SKEW)) %>% # Fjern de første 29 dage uden en fuld måned
  select(Date, Cleaned_OIL_SKEW) # Behold kun Date og Skewness

# 4. Gem den nye fil tilbage i samme mappe
write.csv(oil_skew, paste0(basis_sti, "Cleaned_OIL_SKEW.csv"), row.names = FALSE)

print(paste("✅ SUCCESS! 'Cleaned_OIL_SKEW.csv' er bygget (kun rå skewness) og gemt med", nrow(oil_skew), "observationer."))
