# =========================================================================
# SCRIPT 24: RENSNING AF GPR, GPRT OG GPRA (KUN LOG-AFKAST)
# =========================================================================
library(readxl)
library(dplyr)
library(zoo)
library(lubridate)

print("Starter rensning af Geopolitical Risk Indices (GPR, GPRT, GPRA)...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/gpr_export.xls"

# 2. Indlæs data
gpr_raw <- read_excel(fil_sti)

# 3. Formater datoer i basen
gpr_base <- gpr_raw %>%
  mutate(
    Date = as.Date(parse_date_time(month, orders = c("dmy", "mdy", "ymd")))
  ) %>%
  filter(!is.na(Date)) %>%
  arrange(Date)

# Skab en fuld 7-dages DAGLIG kalender der dækker hele perioden
alle_dage <- data.frame(Date = seq(min(gpr_base$Date), max(gpr_base$Date), by = "days"))

# =========================================================================
# DEL A: Hovedindekset (GPR)
# =========================================================================
gpr_final <- alle_dage %>%
  left_join(gpr_base %>% select(Date, Close = GPR) %>% mutate(Close = as.numeric(Close)), by = "Date") %>%
  mutate(Close_Interp = na.approx(Close, rule = 2)) %>%
  select(Date, Close_Interp) %>% # RETTELSEN: Beholder kun dato og interpoleret data før na.omit
  na.omit() %>%
  mutate(
    # Logaritmiske afkast af den interpolerede linje
    Cleaned_GPR = log(Close_Interp / lag(Close_Interp))
  ) %>%
  select(Date, Cleaned_GPR) %>%
  na.omit()

# =========================================================================
# DEL B: Trusler (GPRT - Threats)
# =========================================================================
gprt_final <- alle_dage %>%
  left_join(gpr_base %>% select(Date, Close = GPRT) %>% mutate(Close = as.numeric(Close)), by = "Date") %>%
  mutate(Close_Interp = na.approx(Close, rule = 2)) %>%
  select(Date, Close_Interp) %>% # RETTELSEN
  na.omit() %>%
  mutate(
    Cleaned_GPRT = log(Close_Interp / lag(Close_Interp))
  ) %>%
  select(Date, Cleaned_GPRT) %>%
  na.omit()

# =========================================================================
# DEL C: Handlinger (GPRA - Acts)
# =========================================================================
gpra_final <- alle_dage %>%
  left_join(gpr_base %>% select(Date, Close = GPRA) %>% mutate(Close = as.numeric(Close)), by = "Date") %>%
  mutate(Close_Interp = na.approx(Close, rule = 2)) %>%
  select(Date, Close_Interp) %>% # RETTELSEN
  na.omit() %>%
  mutate(
    Cleaned_GPRA = log(Close_Interp / lag(Close_Interp))
  ) %>%
  select(Date, Cleaned_GPRA) %>%
  na.omit()

# =========================================================================
# GEM ALLE TRE FILER I LITECOIN MAPPEN
# =========================================================================
basis_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/"

write.csv(gpr_final, paste0(basis_sti, "Cleaned_GPR.csv"), row.names = FALSE)
write.csv(gprt_final, paste0(basis_sti, "Cleaned_GPRT.csv"), row.names = FALSE)
write.csv(gpra_final, paste0(basis_sti, "Cleaned_GPRA.csv"), row.names = FALSE)

cat("\n✅ SUCCESS: Excel-filen er delt op, interpoleret, log-transformeret og gemt som tre separate filer:\n")
cat("1. Cleaned_GPR.csv\n2. Cleaned_GPRT.csv\n3. Cleaned_GPRA.csv\n")
