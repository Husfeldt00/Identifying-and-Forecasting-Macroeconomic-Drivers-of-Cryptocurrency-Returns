# =========================================================================
# SCRIPT 20: RENSNING AF US LONG TREASURY YIELD (KUN SIMPLE DIFFERENCER)
# =========================================================================
library(dplyr)
library(zoo)

print("Starter rensning af US Long Treasury...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/US_long_treas.csv"

# 2. Indlæs data (FRED data)
treas_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og værdier
treas_clean <- treas_raw %>%
  mutate(
    Date = as.Date(observation_date),
    # FRED data bruger ofte "." for manglende dage. as.numeric() laver det om til NA
    Close = suppressWarnings(as.numeric(DLTIIT))
  ) %>%
  select(Date, Close) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# 4. Skab en fuld 7-dages kalender (VIGTIGT FOR RENTER - na.locf)
alle_dage <- data.frame(Date = seq(min(treas_clean$Date), max(treas_clean$Date), by = "days"))

treas_interp <- alle_dage %>%
  left_join(treas_clean, by = "Date") %>%
  mutate(
    # Fyld huller ud med sidste kendte rente (Fredagens rente gælder lørdag/søndag)
    Close_Interp = na.locf(Close, na.rm = FALSE)
  ) %>%
  na.omit()

# 5. Matematik jf. Panagiotidis (2018) - INGEN LOG OG INGEN 2-DAY AVERAGE
treas_final <- treas_interp %>%
  mutate(
    # SIMPLE differencer (Fordi realrenter kan være negative!)
    Cleaned_TREAS = Close_Interp - lag(Close_Interp)
  ) %>%
  select(Date, Cleaned_TREAS) %>%
  na.omit() # Fjerner den første observation

# 6. Gem resultatet i din nye Litecoin 'Cleaned_CSV' mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/Cleaned_TREAS.csv"
write.csv(treas_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset Treasury-data:\n")
print(head(treas_final))
cat("\n✅ SUCCESS: US Long Treasury er renset (simpel difference) og gemt i den nye mappe.\n")
