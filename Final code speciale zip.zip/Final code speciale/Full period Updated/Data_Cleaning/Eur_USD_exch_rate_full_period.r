# =========================================================================
# SCRIPT 6: RENSNING AF EUR/USD (MED INTERPOLATION)
# =========================================================================
library(dplyr)
library(zoo)
library(lubridate)

print("Starter rensning af EUR/USD...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/EUR_USD Historical Data.csv"

# 2. Indlæs data
eur_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og forbered til interpolation
eur_clean <- eur_raw %>%
  mutate(
    # Fanger formatet "MM/DD/YYYY"
    Date = as.Date(parse_date_time(Date, orders = c("mdy", "dmy", "ymd"))),
    # Fanger prisen. Fjerner evt. kommaer fra store tal for en sikkerheds skyld
    Close = as.numeric(gsub(",", "", Price))
  ) %>%
  select(Date, Close) %>%
  # VIGTIGT: Sorterer kronologisk, da rådataen ofte er baglæns
  arrange(Date) %>%
  filter(!is.na(Date))

# 4. Skab en fuld 7-dages kalender og flet dataen
alle_dage <- data.frame(Date = seq(min(eur_clean$Date), max(eur_clean$Date), by = "days"))

eur_interp <- alle_dage %>%
  left_join(eur_clean, by = "Date") %>%
  mutate(
    # Lineær interpolation (udfylder weekender)
    Close_Interp = na.approx(Close, na.rm = FALSE)
  ) %>%
  na.omit()

# 5. Matematik jf. Panagiotidis (2018)
eur_final <- eur_interp %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Log_Return = log(Close_Interp) - log(lag(Close_Interp)),
    
    # 2-dages glidende gennemsnit
    EUR_2d = rollmean(Log_Return, k = 2, fill = NA, align = "right")
  ) %>%
  filter(!is.na(EUR_2d)) %>%
  mutate(
    # Standardisering (Mean = 0, Varians = 1)
    eur_standardized = as.numeric(scale(EUR_2d))
  ) %>%
  select(Date, eur_standardized)

# 6. Gem resultatet
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Cleaned_EUR.csv"
write.csv(eur_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset og interpoleret EUR/USD-data:\n")
print(head(eur_final))
cat("\n✅ SUCCESS: EUR/USD er renset, interpoleret og gemt som 'Cleaned_EUR.csv'.\n")