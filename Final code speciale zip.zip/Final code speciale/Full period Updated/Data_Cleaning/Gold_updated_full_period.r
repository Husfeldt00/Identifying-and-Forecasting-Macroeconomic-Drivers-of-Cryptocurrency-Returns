# =========================================================================
# SCRIPT 3: RENSNING AF GULD (GOLD NY FUTURES) - KUN LOG-AFKAST
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af Guld (NY Futures)...")

# 1. Definer stien til din NY RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/Gold Futures Historical Data_NY.csv"

# 2. Indlæs data 
# BEMÆRK: Ændret til read.csv da '_NY' filer typisk bruger amerikansk format (komma og punktum)
gold_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Automatisk håndtering af kolonnenavne (Price/Close -> Value)
if("Price" %in% colnames(gold_raw)) {
  gold_raw <- gold_raw %>% rename(Value = Price)
} else if("Close" %in% colnames(gold_raw)) {
  gold_raw <- gold_raw %>% rename(Value = Close)
}

# 4. Formater datoer og forbered data
gold_clean <- gold_raw %>%
  mutate(
    # Fanger datoformatet dmy (dag-måned-år), mdy eller ymd
    Date = as.Date(parse_date_time(Date, orders = c("dmy", "mdy", "ymd"))),
    
    # Fjern eventuelle amerikanske tusindtals-kommaer (f.eks. 1,900.50 -> 1900.50) inden konvertering
    Value_clean = gsub(",", "", Value),
    Close = as.numeric(Value_clean)
  ) %>%
  select(Date, Close) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# 5. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
gold_final <- gold_clean %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_GOLD = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_GOLD) %>%
  na.omit() # Fjerner den første observation (NA pga. lag)

# 6. Gem resultatet i din Litecoin 'Cleaned_CSV' mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period Updated/Cleaned_CSV/Cleaned_GOLD_NY.csv"
write.csv(gold_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset Guld-data (NY Futures):\n")
print(head(gold_final))
cat("\n✅ SUCCESS: Guld fra NY-filen er renset (kun log-afkast) og gemt i din Cleaned_CSV mappe.\n")