# =========================================================================
# SCRIPT 4: RENSNING AF FED FUNDS RATE (KUN SIMPLE DIFFERENCER)
# =========================================================================
library(dplyr)
library(zoo)

print("Starter rensning af FED-renten...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/Fed_fund_effective_rate.csv"

# 2. Indlæs data
fed_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og værdier
fed_clean <- fed_raw %>%
  mutate(
    Date = as.Date(observation_date),
    # Fanger værdien og gør den numerisk
    Rate = suppressWarnings(as.numeric(DFF))
  ) %>%
  select(Date, Rate) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Rate))

# 4. Skab en fuld 7-dages kalender (VIGTIGT FOR RENTER)
alle_dage <- data.frame(Date = seq(min(fed_clean$Date), max(fed_clean$Date), by = "days"))

fed_interp <- alle_dage %>%
  left_join(fed_clean, by = "Date") %>%
  mutate(
    # Fyld huller ud med sidste kendte rente (Fredagens rente gælder lørdag/søndag)
    Rate_Interp = na.locf(Rate, na.rm = FALSE)
  ) %>%
  na.omit()

# 5. Matematik jf. Panagiotidis (2018) - INGEN LOG OG INGEN 2-DAY AVERAGE
fed_final <- fed_interp %>%
  mutate(
    # SIMPLE differencer (IKKE log-afkast)
    Cleaned_FED = Rate_Interp - lag(Rate_Interp)
  ) %>%
  select(Date, Cleaned_FED) %>%
  na.omit() # Fjerner den første observation

# 6. Gem resultatet i din nye Litecoin 'Cleaned_CSV' mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/Cleaned_FED.csv"
write.csv(fed_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset FED-data:\n")
print(head(fed_final))
cat("\n✅ SUCCESS: FED er renset (simpel difference) og gemt i den nye mappe.\n")
