# =========================================================================
# SCRIPT 10: RENSNING AF DOW JONES (DJ) - KUN LOG-AFKAST
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af Dow Jones...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/Dow Jones Industrial Average Historical Data.csv"

# 2. Indlæs data
dj_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og rens priser
dj_clean <- dj_raw %>%
  mutate(
    # Fanger formatet "MM/DD/YYYY"
    Date = as.Date(parse_date_time(Date, orders = c("mdy", "dmy", "ymd"))),
    # Fjerner tusindtalskommaer og konverterer til tal
    Close = as.numeric(gsub(",", "", Price))
  ) %>%
  # Vi fjerner dage uden volumen (som typisk er de "falske" forudfyldte weekender/helligdage)
  filter(Vol. != "") %>%
  select(Date, Close) %>%
  # Sorterer kronologisk
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
dj_final <- dj_clean %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_DJ = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_DJ) %>%
  na.omit() # Fjerner den første observation pga. lag

# 5. Gem resultatet i din nye Litecoin 'Cleaned_CSV' mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/Cleaned_DJ.csv"
write.csv(dj_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset Dow Jones-data:\n")
print(head(dj_final))
cat("\n✅ SUCCESS: Dow Jones er renset (kun log-afkast) og gemt i den nye mappe.\n")
