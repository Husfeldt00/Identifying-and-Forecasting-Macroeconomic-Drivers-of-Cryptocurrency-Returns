# =========================================================================
# SCRIPT 9: RENSNING AF JPY/USD - KUN LOG-AFKAST
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af JPY/USD...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/JPY_USD Historical Data.csv"

# 2. Indlæs data
jpy_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og forbered data
jpy_clean <- jpy_raw %>%
  mutate(
    # Fanger formatet "MM/DD/YYYY"
    Date = as.Date(parse_date_time(Date, orders = c("mdy", "dmy", "ymd"))),
    # Fanger prisen og fjerner evt. kommaer
    Close = as.numeric(gsub(",", "", Price))
  ) %>%
  select(Date, Close) %>%
  # Sorterer kronologisk
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
jpy_final <- jpy_clean %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_JPY = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_JPY) %>%
  na.omit() # Fjerner den første observation (NA pga. lag)

# 5. Gem resultatet i din nye Litecoin 'Cleaned_CSV' mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/Cleaned_JPY.csv"
write.csv(jpy_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset JPY/USD-data:\n")
print(head(jpy_final))
cat("\n✅ SUCCESS: JPY/USD er renset (kun log-afkast) og gemt i den nye mappe.\n")
