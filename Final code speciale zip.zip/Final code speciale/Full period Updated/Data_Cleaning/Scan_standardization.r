# =========================================================================
# SCRIPT: TJEK FOR STANDARDISERING I CLEANED FILER
# =========================================================================
library(dplyr)
library(readr)

print("Skanner Cleaned-filer for standardisering (Mean = 0, SD = 1)...")

# 1. Definer stien til din mappe
sti_load <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/"

# 2. Hent en liste over alle CSV-filer i mappen
filer <- list.files(path = sti_load, pattern = "\\.csv$", full.names = TRUE)

# 3. Gør en tom tabel klar til resultaterne
resultater <- data.frame(
  Variable = character(), 
  Mean = numeric(), 
  SD = numeric(), 
  Standardiseret = character(), 
  stringsAsFactors = FALSE
)

# 4. Loop igennem alle filer og test dem
for (fil in filer) {
  # Læs filen lydløst
  df <- tryCatch(read_csv(fil, show_col_types = FALSE), error = function(e) NULL)
  
  if (!is.null(df)) {
    # Find den første numeriske kolonne, der IKKE er Dato
    num_data <- df %>% select(where(is.numeric)) %>% pull(1)
    
    # Beregn matematikken
    mu <- mean(num_data, na.rm = TRUE)
    sigma <- sd(num_data, na.rm = TRUE)
    
    # Tjek om det er standardiseret (vi tillader en lille smule afrundingsstøj, fx 0.0001)
    # Mean skal være tæt på 0, og SD skal være tæt på 1
    is_stand <- ifelse(abs(mu) < 0.05 && abs(sigma - 1) < 0.05, "✅ JA", "❌ NEJ")
    
    # Gem filnavnet uden hele stien
    var_navn <- basename(fil)
    
    resultater <- rbind(resultater, data.frame(
      Variable = var_navn,
      Mean = round(mu, 4),
      SD = round(sigma, 4),
      Standardiseret = is_stand
    ))
  }
}

# 5. Print den flotte oversigt
cat("\n--- RESULTAT AF SKANNING ---\n")
print(resultater)
