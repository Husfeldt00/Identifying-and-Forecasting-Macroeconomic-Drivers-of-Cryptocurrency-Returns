# =========================================================================
# SCRIPT 16: RENSNING AF EPU (RETTET INTERPOLATION)
# =========================================================================
library(readxl)
library(dplyr)
library(zoo)
library(lubridate)

fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/Europe_Policy_Uncertainty_Data.xlsx"
epu_raw <- read_excel(fil_sti)

epu_clean <- epu_raw %>%
  mutate(
    Date = make_date(year = Year, month = Month, day = 1),
    Close = as.numeric(European_News_Index)
  ) %>%
  select(Date, Close) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close))

alle_dage <- data.frame(Date = seq(min(epu_clean$Date), max(epu_clean$Date), by = "days"))

epu_interp <- alle_dage %>%
  left_join(epu_clean, by = "Date") %>%
  mutate(Close_Interp = na.approx(Close, rule = 2)) %>%
  # RETTELSEN: Vi beholder KUN Date og den interpolerede kolonne, FØR vi sletter NAs
  select(Date, Close_Interp) %>% 
  na.omit()

epu_final <- epu_interp %>%
  mutate(Cleaned_EPU = log(Close_Interp / lag(Close_Interp))) %>%
  select(Date, Cleaned_EPU) %>%
  na.omit() 

gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/Cleaned_EPU.csv"
write.csv(epu_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af RETTET EPU-data (læg mærke til at vi nu har daglige datoer!):\n")
print(head(epu_final, 5))
