# =========================================================================
# SCRIPT 2: RENSNING AF RÅOLIE (KUN LOG-AFKAST + 2020 FIX)
# =========================================================================
library(dplyr)
library(lubridate)

print("Starter rensning af Råolie...")

# 1. Definer stien til din RAW fil
fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period/Raw_data_full_period/crude-oil-price.csv"

# 2. Indlæs data
oil_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

# 3. Formater datoer og rens data
oil_clean <- oil_raw %>%
  mutate(
    Date = as.Date(observation_date),
    Close = suppressWarnings(as.numeric(DCOILWTICO))
  ) %>%
  # VIGTIGT FIX: Vi filtrerer NA's væk, OG vi fjerner negative priser (April 2020)
  filter(!is.na(Date), !is.na(Close), Close > 0) %>%
  select(Date, Close) %>%
  arrange(Date)

# 4. Matematik jf. Panagiotidis (2018) - KUN LOG-DIFFERENCE
oil_final <- oil_clean %>%
  mutate(
    # Logaritmiske afkast i logaritmisk første difference
    Cleaned_OIL = log(Close / lag(Close))
  ) %>%
  select(Date, Cleaned_OIL) %>%
  na.omit() # Fjerner den første observation pga. lag

# 5. Gem resultatet i din nye Litecoin 'Cleaned_CSV' mappe
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period LiteCoin/Cleaned_CSV/Cleaned_OIL.csv"
write.csv(oil_final, gem_sti, row.names = FALSE)

cat("\nFørste 5 rækker af renset Råolie-data:\n")
print(head(oil_final))
cat("\n✅ SUCCESS: Råolie er fikset for 2020-crashet, renset (kun log-afkast) og gemt i den nye mappe.\n")
