files <- list.files(getwd(), recursive = TRUE, full.names = TRUE, pattern = "\\.R$")

for (f in files) {
  txt <- readLines(f, warn = FALSE)
  
  if (any(grepl("C:/Users", txt))) {
    cat("STADIG PROBLEM I:", f, "\n")
  }
}
