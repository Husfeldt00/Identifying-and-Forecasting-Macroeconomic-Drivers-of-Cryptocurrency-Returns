# =========================================================================
# OUT-OF-SAMPLE FORECASTING (BITCOIN) COMBINATIONS (ALLE DELTAER)
# =========================================================================
library(dplyr)
library(glmnet)



# 1. DATA

source("00_paths.R")
basis_sti <- cleaned_sti

df_full <- read.csv(paste0(basis_sti, "MASTER_Full_Period.csv"))
df_full$Date <- as.Date(df_full$Date)

df_full <- df_full %>% 
  arrange(Date) %>% 
  select(
    -contains("cpnews_index_narrow"),
    -contains("cpsent_index"),
    -contains("cpu_index_broad"),
    -contains("cpu_index_narrow")
  ) %>% 
  na.omit()

# =========================================================================
# LASSO FUNCTION
# =========================================================================
get_lasso_vars <- function(X_pool, y_target) {
  set.seed(123)
  fit <- tryCatch(cv.glmnet(as.matrix(X_pool), y_target, alpha=1, standardize=FALSE),
                  error=function(e) NULL)
  
  if(!is.null(fit)){
    c <- as.matrix(coef(fit, s="lambda.min"))
    return(rownames(c)[c[,1] != 0 & rownames(c) != "(Intercept)"])
  } else return(character(0))
}

# =========================================================================
# MAIN FUNCTION
# =========================================================================
run_oos_evaluation_comb <- function(split_ratio, split_navn) {
  
  N_total <- nrow(df_full)
  N_train <- floor(split_ratio * N_total)
  
  df_train <- df_full[1:N_train, ]
  df_test  <- df_full[(N_train + 1):N_total, ]
  
  y_train <- df_train$Cleaned_BTC
  y_test_actual <- df_test$Cleaned_BTC
  N_test <- length(y_test_actual)
  
  # =========================================================================
  # VARIABLE POOL 
  # =========================================================================
  X_train_pool <- df_train %>% 
    select(-Date, -Cleaned_BTC) %>%
    select(-any_of(c("Cleaned_ETH", "Lag1_ETH", "ETH_Volume",
                     "Cleaned_LTC", "Lag1_LTC", "Litecoin_Volume",
                     "Cleaned_XRP", "Lag1_XRP", "XRP_Volume",
                     "Bitcoin_Volume"))) %>%
    select(where(~ sd(.) > 0))
  
  # =========================================================================
  # VARIABLE SELECTION (ALLE 7 MODELLER)
  # =========================================================================
  vars_lasso <- get_lasso_vars(X_train_pool, y_train)
  
  # OCMT Varianter
  vars_ocmt_05 <- run_ocmt_safe_0.5(as.matrix(X_train_pool), y_train, 0.05)
  vars_ocmt_10 <- run_ocmt_safe(as.matrix(X_train_pool), y_train, 0.05)
  vars_ocmt_20 <- run_ocmt_safe_2.0(as.matrix(X_train_pool), y_train, 0.05)
  
  # BMT Varianter
  vars_bmt_05  <- run_bmt_safe_0.5(as.matrix(X_train_pool), y_train, 0.05)
  vars_bmt_10  <- run_bmt_safe(as.matrix(X_train_pool), y_train, 0.05)
  vars_bmt_20  <- run_bmt_safe_2.0(as.matrix(X_train_pool), y_train, 0.05)
  
  # =========================================================================
  # FORECAST FUNCTION
  # =========================================================================
  forecast_model <- function(navn, valgte_vars) {
    
    valgte_gyldige <- intersect(valgte_vars, colnames(X_train_pool))
    
    if(length(valgte_gyldige) > 0) {
      df_reg_train <- data.frame(y = y_train,
                                 X_train_pool[, valgte_gyldige, drop=FALSE])
      df_reg_test  <- data.frame(df_test[, valgte_gyldige, drop=FALSE])
      
      fit_train <- lm(y ~ ., data = df_reg_train)
      y_hat_test <- predict(fit_train, newdata = df_reg_test)
      
    } else {
      mean_train <- mean(y_train)
      y_hat_test <- rep(mean_train, nrow(df_test))
    }
    
    e_test <- y_test_actual - y_hat_test
    msfe <- mean(e_test^2)
    
    return(list(Navn = navn,
                MSFE = msfe,
                Predictions = y_hat_test))
  }
  
  # =========================================================================
  # BENCHMARK = MEAN
  # =========================================================================
  mean_train <- mean(y_train)
  y_hat_mean_bench <- rep(mean_train, nrow(df_test))
  msfe_benchmark <- mean((y_test_actual - y_hat_mean_bench)^2)
  
  res_mean <- list(Navn = "1. Mean Benchmark",
                   MSFE = msfe_benchmark)
  
  # =========================================================================
  # MODELS EVALUATION
  # =========================================================================
  res_lasso   <- forecast_model("2. LASSO", vars_lasso)
  
  res_ocmt_05 <- forecast_model("3. OCMT (0.5)", vars_ocmt_05)
  res_ocmt_10 <- forecast_model("4. OCMT (1.0)", vars_ocmt_10)
  res_ocmt_20 <- forecast_model("5. OCMT (2.0)", vars_ocmt_20)
  
  res_bmt_05  <- forecast_model("6. BMT (0.5)", vars_bmt_05)
  res_bmt_10  <- forecast_model("7. BMT (1.0)", vars_bmt_10)
  res_bmt_20  <- forecast_model("8. BMT (2.0)", vars_bmt_20)
  
  # =========================================================================
  # FORECAST COMBINATIONS (ALLE 7 MODELLER INDGÅR)
  # =========================================================================
  preds_mat <- cbind(
    res_lasso$Predictions,
    res_ocmt_05$Predictions, res_ocmt_10$Predictions, res_ocmt_20$Predictions,
    res_bmt_05$Predictions,  res_bmt_10$Predictions,  res_bmt_20$Predictions
  )
  
  # Mean
  y_hat_mean <- rowMeans(preds_mat)
  
  # Median (TMean)
  y_hat_median <- apply(preds_mat, 1, median)
  
  # DMSPE (1.0)
  y_hat_dmspe_10 <- numeric(N_test)
  y_hat_dmspe_10[1] <- mean(preds_mat[1, ])
  
  # DMSPE (0.9)
  y_hat_dmspe_09 <- numeric(N_test)
  y_hat_dmspe_09[1] <- mean(preds_mat[1, ])
  
  for (t in 2:N_test) {
    
    err_lasso   <- y_test_actual[1:(t-1)] - res_lasso$Predictions[1:(t-1)]
    err_ocmt_05 <- y_test_actual[1:(t-1)] - res_ocmt_05$Predictions[1:(t-1)]
    err_ocmt_10 <- y_test_actual[1:(t-1)] - res_ocmt_10$Predictions[1:(t-1)]
    err_ocmt_20 <- y_test_actual[1:(t-1)] - res_ocmt_20$Predictions[1:(t-1)]
    err_bmt_05  <- y_test_actual[1:(t-1)] - res_bmt_05$Predictions[1:(t-1)]
    err_bmt_10  <- y_test_actual[1:(t-1)] - res_bmt_10$Predictions[1:(t-1)]
    err_bmt_20  <- y_test_actual[1:(t-1)] - res_bmt_20$Predictions[1:(t-1)]
    
    # DMSPE (1.0)
    phi_10 <- c(
      sum(err_lasso^2),
      sum(err_ocmt_05^2), sum(err_ocmt_10^2), sum(err_ocmt_20^2),
      sum(err_bmt_05^2), sum(err_bmt_10^2), sum(err_bmt_20^2)
    )
    w_10 <- (1 / phi_10) / sum(1 / phi_10)
    y_hat_dmspe_10[t] <- sum(w_10 * preds_mat[t, ])
    
    # DMSPE (0.9)
    discount <- 0.9^((t-2):0)
    phi_09 <- c(
      sum(discount * err_lasso^2),
      sum(discount * err_ocmt_05^2), sum(discount * err_ocmt_10^2), sum(discount * err_ocmt_20^2),
      sum(discount * err_bmt_05^2), sum(discount * err_bmt_10^2), sum(discount * err_bmt_20^2)
    )
    
    w_09 <- (1 / phi_09) / sum(1 / phi_09)
    y_hat_dmspe_09[t] <- sum(w_09 * preds_mat[t, ])
  }
  
  # =========================================================================
  # RESULT TABLE
  # =========================================================================
  eval_comb <- function(navn, y_hat) {
    msfe <- mean((y_test_actual - y_hat)^2)
    r2 <- 1 - msfe / msfe_benchmark
    
    data.frame(Model = navn, MSFE = msfe, R2_OOS = r2 * 100)
  }
  
  byg_raekke <- function(res) {
    r2 <- 1 - res$MSFE / msfe_benchmark
    data.frame(Model = res$Navn, MSFE = res$MSFE, R2_OOS = r2 * 100)
  }
  
  tab <- bind_rows(
    byg_raekke(res_mean),
    byg_raekke(res_lasso),
    byg_raekke(res_ocmt_05),
    byg_raekke(res_ocmt_10),
    byg_raekke(res_ocmt_20),
    byg_raekke(res_bmt_05),
    byg_raekke(res_bmt_10),
    byg_raekke(res_bmt_20),
    eval_comb("9. Comb Mean", y_hat_mean),
    eval_comb("10. Comb Median (TMean)", y_hat_median),
    eval_comb("11. Comb DMSPE (1.0)", y_hat_dmspe_10),
    eval_comb("12. Comb DMSPE (0.9)", y_hat_dmspe_09)
  )
  
  cat("\n=======================================================\n")
  cat(sprintf("RESULTATER (%s split)\n", split_navn))
  cat("=======================================================\n")
  print(tab %>% mutate(
    MSFE = sprintf("%.5f", MSFE),
    R2_OOS = sprintf("%.3f %%", R2_OOS)
  ))
}

# =========================================================================
# RUN
# =========================================================================
run_oos_evaluation_comb(0.80, "80/20")
run_oos_evaluation_comb(0.90, "90/10")
