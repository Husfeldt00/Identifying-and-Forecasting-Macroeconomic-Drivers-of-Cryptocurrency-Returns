# =========================================================================
# SCRIPT 0: PERMANENT RENSNING AF CSV-FILER PÅ HARDDISKEN
# =========================================================================
library(dplyr)

basis_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Code_Speciale/Full period Updated/Cleaned_CSV/"
filer <- c("MASTER_Full_Period.csv", "MASTER_P1.csv", "MASTER_P2.csv", "MASTER_P3.csv", "MASTER_P4.csv")



for (fil in filer) {
  fuld_sti <- paste0(basis_sti, fil)
  
  if (file.exists(fuld_sti)) {
    # 1. Læs filen
    df <- read.csv(fuld_sti)
    antal_før <- ncol(df)
    
    # 2. Fjern klimavariabler (hvis de findes)
    df_renset <- df %>%
      select(
        -contains("cpnews_index_narrow"),
        -contains("cpsent_index"),
        -contains("cpu_index_broad"),
        -contains("cpu_index_narrow")
      )
    antal_efter <- ncol(df_renset)
    
    # 3. Gem 
    write.csv(df_renset, fuld_sti, row.names = FALSE)
    
    cat(" Opdateret:", fil, "- Fjernede", (antal_før - antal_efter), "kolonner.\n")
    
  } else {
    cat(" Kunne ikke finde:", fil, "\n")
  }
}
