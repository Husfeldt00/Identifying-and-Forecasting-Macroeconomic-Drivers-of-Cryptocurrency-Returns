# 00_paths.R

cleaned_sti <- paste0(getwd(), "/Cleaned_CSV/")
raw_sti     <- paste0(getwd(), "/Raw_data_full_period/")

cat("Working directory:", getwd(), "\n")
cat("Cleaned path:", cleaned_sti, "\n")
