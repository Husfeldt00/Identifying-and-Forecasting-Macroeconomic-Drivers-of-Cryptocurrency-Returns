files <- list.files(
  path = getwd(),
  pattern = "\\.R$",
  recursive = TRUE,
  full.names = TRUE
)

for (f in files) {
  
  txt <- readLines(f, warn = FALSE)
  
  # Fjern gamle hardcoded paths
  txt <- txt[!grepl("C:/Users", txt)]
  
  # Indsæt ny base path øverst hvis ikke findes
  if (!any(grepl("00_paths.R", txt))) {
    txt <- c(
      'source("00_paths.R")',
      'basis_sti <- cleaned_sti',
      '',
      txt
    )
  }
  
  writeLines(txt, f)
  
  cat("Fixed:", f, "\n")
}

list.files()
