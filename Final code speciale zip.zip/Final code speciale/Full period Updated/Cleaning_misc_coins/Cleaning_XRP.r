# =========================================================================
# SCRIPT: RENSNING AF RIPPLE (XRP)
# =========================================================================
library(dplyr)
library(lubridate)
library(stringr)



fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/XRP Historical Data.csv"
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code speciale/Full period Updated/Cleaning_misc_coins/Cleaned_XRP.csv"

xrp_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

xrp_final <- xrp_raw %>%
  mutate(
    Date = mdy(Date),
    Price_Numeric = as.numeric(str_replace_all(Price, ",", ""))
  ) %>%
  arrange(Date) %>%
  mutate(Cleaned_XRP = log(Price_Numeric / lag(Price_Numeric))) %>%
  select(Date, Cleaned_XRP) %>%
  na.omit()

write.csv(xrp_final, gem_sti, row.names = FALSE)
