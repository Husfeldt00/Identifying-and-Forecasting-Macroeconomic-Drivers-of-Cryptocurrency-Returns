# =========================================================================
# SCRIPT: RENSNING AF ETHEREUM (ETH)
# =========================================================================
library(dplyr)
library(lubridate)
library(stringr)



fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/Ethereum Historical Data.csv"
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code speciale/Full period Updated/Cleaning_misc_coins/Cleaned_ETH.csv"

eth_raw <- read.csv(fil_sti, stringsAsFactors = FALSE)

eth_final <- eth_raw %>%
  mutate(
    Date = mdy(Date),
    Price_Numeric = as.numeric(str_replace_all(Price, ",", ""))
  ) %>%
  arrange(Date) %>%
  mutate(Cleaned_ETH = log(Price_Numeric / lag(Price_Numeric))) %>%
  select(Date, Cleaned_ETH) %>%
  na.omit()

write.csv(eth_final, gem_sti, row.names = FALSE)
