# =========================================================================
# SCRIPT 1: RENSNING AF LITECOIN (LTC)
# =========================================================================
library(dplyr)
library(lubridate)



fil_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code Speciale/Full period Updated/Raw_data_full_period/price_history_LTC.csv"
gem_sti <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code speciale/Full period Updated/Cleaning_misc_coins/Cleaned_LTC.csv"

ltc_raw <- read.csv(fil_sti, sep = ";", stringsAsFactors = FALSE)

ltc_final <- ltc_raw %>%
  mutate(
    Date = mdy(Date),
    Close = as.numeric(gsub("\\$", "", Close))
  ) %>%
  arrange(Date) %>%
  filter(!is.na(Date), !is.na(Close)) %>%
  mutate(Cleaned_LTC = log(Close / lag(Close))) %>%
  select(Date, Cleaned_LTC) %>%
  na.omit()

write.csv(ltc_final, gem_sti, row.names = FALSE)

