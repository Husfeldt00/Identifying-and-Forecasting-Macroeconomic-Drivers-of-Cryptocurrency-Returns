# =========================================================================
# MASTER SCRIPT: ETHEREUM, LITECOIN & RIPPLE
# =========================================================================
library(dplyr)
library(purrr)
library(zoo)
library(readr)
library(lubridate)



# 1. Definer stier

source("00_paths.R")
basis_sti <- cleaned_sti

misc_sti  <- "C:/Users/mhusf/OneDrive/Dokumenter/Uni/10. Semester/Final code speciale/Full period Updated/Cleaning_misc_coins/"

# =========================================================================
# 2. BYG MAKRO-FUNDAMENTET (UDEN BTC)
# =========================================================================
# Find alle rensede filer i hovedmappen
alle_makro_filer <- list.files(path = basis_sti, pattern = "^Cleaned_.*\\.csv$", full.names = TRUE)

# Sikkerhed: ekskluderer Cleaned_BTC fra listen af filer
alle_makro_filer <- alle_makro_filer[!grepl("Cleaned_BTC\\.csv", alle_makro_filer)]

print(paste("Fandt", length(alle_makro_filer), "makro-filer. Samler dem nu..."))

# Indlæs og flet alle makro-filer
master_makro_raw <- alle_makro_filer %>%
  map(read.csv) %>%
  reduce(full_join, by = "Date") %>%
  mutate(Date = as.Date(Date)) %>%
  arrange(Date) %>%
  # Dobbelt sikkerhed: Fjern alt relateret til BTC
  select(-contains("BTC"))

# =========================================================================
# 3. HOVEDFUNKTION: BYG, INTERPOLER, SMOOTH OG STANDARDISER EN COIN
# =========================================================================
build_crypto_master <- function(kort_navn, langt_navn) {
  cat("\n=======================================================\n")
  cat("Starter bygning af master-fil for:", langt_navn, "...\n")
  
  # A) Indlæs den rå krypto-data fra misc_sti
  crypto_fil <- paste0(misc_sti, "Cleaned_", kort_navn, ".csv")
  df_crypto <- read.csv(crypto_fil) %>%
    mutate(Date = as.Date(Date))
  
  # B) Find start- og slutdato
  start_dato <- min(df_crypto$Date, na.rm = TRUE)
  slut_dato  <- as.Date("2024-12-31")
  
  cat("-> Kryptoens første observation er:", as.character(start_dato), "\n")
  
  # C) Skab en kalender, der KUN eksisterer i kryptoens levetid
  kalender <- data.frame(Date = seq(start_dato, slut_dato, by = "days"))
  
  # D) Flet kalenderen med makro-data OG krypto-data
  master_interp <- kalender %>%
    left_join(master_makro_raw, by = "Date") %>%
    left_join(df_crypto, by = "Date") %>%
    arrange(Date)
  
  # E) Interpolation (fylder nuller/helligdage ud)
  master_interp <- master_interp %>%
    mutate(
      across(
        c(any_of("Cleaned_FED"), any_of("Cleaned_ECB"), any_of("Cleaned_TREAS")), 
        ~ na.locf(.x, na.rm = FALSE)
      ),
      across(
        -c(Date, any_of("Cleaned_FED"), any_of("Cleaned_ECB"), any_of("Cleaned_TREAS")), 
        ~ na.approx(.x, na.rm = FALSE, rule = 2)
      )
    )
  
  # F) Glidende gennemsnit (Smooth)
  renter <- c("Cleaned_FED", "Cleaned_ECB", "Cleaned_TREAS")
  master_smoothed <- master_interp %>%
    mutate(
      across(
        -c(Date, any_of(renter)),
        ~ rollmean(.x, k = 2, fill = NA, align = "right")
      )
    ) %>%
    na.omit() # Fjerner de rækker der mangler data pga. start-lag
  
  cat("-> Data interpoleret og smoothed. Klipper og standardiserer nu...\n")
  
  # G) Hjælpefunktion til at standardisere og gemme perioder
  slice_and_scale <- function(df, start, slut, suffix) {
    sliced_df <- df %>% filter(Date >= as.Date(start) & Date <= as.Date(slut))
    
    if(nrow(sliced_df) > 0) {
      scaled_df <- sliced_df %>% mutate(across(-Date, ~ as.numeric(scale(.x))))
      
      gem_sti <- paste0(basis_sti, "MASTER_", langt_navn, "_", suffix, ".csv")
      write.csv(scaled_df, gem_sti, row.names = FALSE)
      cat(sprintf("   ✅ Oprettet: MASTER_%s_%s.csv (Rækker: %d)\n", langt_navn, suffix, nrow(scaled_df)))
    }
  }
  
  # 1. Gem Full Period
  slice_and_scale(master_smoothed, start_dato, slut_dato, "Full_Period")
  
  # 2. Gem P1, P2, P3 (for Litecoin)
  if(kort_navn == "LTC") {
    slice_and_scale(master_smoothed, "2013-10-02", "2017-01-03", "P1")
    slice_and_scale(master_smoothed, "2017-01-04", "2017-06-23", "P2")
    slice_and_scale(master_smoothed, "2017-06-24", "2024-12-31", "P3")
  }
}

# =========================================================================
# 4. KØR PROCESSEN FOR ALLE TRE COINS
# =========================================================================

build_crypto_master("ETH", "ETHEREUM")
build_crypto_master("XRP", "RIPPLE")
build_crypto_master("LTC", "LITECOIN")

